export const DarkSchema = {}
