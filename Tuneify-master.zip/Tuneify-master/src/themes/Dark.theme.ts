export const LightScheme = {}
