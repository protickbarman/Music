<div align="center">
  
# Tuneify
[![made-with-Reac-Native](https://img.shields.io/badge/Made%20with-React_Native-1f425f.svg)](https://reactnative.dev/)


<center>
  
 ### Let the Beat Move You: <br/>
 ### <code>Tuneify</code> - Your Rhythm, Your Groove! <br/>

 Experience music without limits with Tuneify, the open-source music app. Join a community of creators and listeners, shaping the future of music together. Customize your experience, contribute, and redefine how you enjoy music, all in one app.

 ### <code>Note</code> :<ins>Monthly major update</ins>
</center>



## Download Link [ v2.0.0] [old versions](https://github.com/estd20xx/Tuneify/releases)  

Architecture | Link | Size
--- | --- | ---
Tuneify Universal | [Download](https://github.com/estd20xx/Tuneify/releases/download/v2.0.0/app-universal-release.apk) | 27.2 MB
Tuneify arm64-v8a | [Download](https://github.com/estd20xx/Tuneify/releases/download/v2.0.0/app-arm64-v8a-release.apk) | 14.4 MB
Tuneify armeabi-v7a | [Download](https://github.com/estd20xx/Tuneify/releases/download/v2.0.0/app-armeabi-v7a-release.apk) | 13.5 MB
Tuneify x86_64 | [Download](https://github.com/estd20xx/Tuneify/releases/download/v2.0.0/app-x86_64-release.apk) | 14.7 MB
Tuneify x86 | [Download](https://github.com/estd20xx/Tuneify/releases/download/v2.0.0/app-x86-release.apk) | 14.8 MB



![Tuneify Preview](https://raw.githubusercontent.com/estd20xx/Tuneify/master/src/assets/preview.jpg)


<img src="https://github.com/user-attachments/assets/4afd626e-517e-4a7e-bce6-edd6f0c4fb18"/>

![Screenshot 2025-02-07 152200](https://github.com/user-attachments/assets/79828d11-02c6-48c9-9fca-45d67906ce4f)

![Screenshot 2025-06-03 233712](https://github.com/user-attachments/assets/4ee48349-b1d0-4acf-87fb-7c80e9d09087)


</div>
