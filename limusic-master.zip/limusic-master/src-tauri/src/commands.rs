//! Tauri commands — the ONLY API the UI calls. context/11 UI contract. No YouTube shapes leak
//! past here; the UI never sees a stream URL.

use std::sync::Arc;

use innertube::{
    ActionError, AlbumPage, ArtistPage, BrowseItem, Comment, CommentAction, CommentReplies,
    CommentThread, CommentWrite, CommentsPage, HistoryGroup, HomePage, MoodSection,
    PlaylistContinuation, PlaylistPage, PlaylistSort, PlaylistSuggestions, Provenance, Rating,
    SearchResults, SearchSuggestions, SongItem, VoteState,
};
use tauri::{Emitter, Manager, State};

use crate::blocked::BlockedArtist;
use crate::state::{
    is_local_playlist, AppState, LOCAL_PLAYLIST_PREFIX, ON_REPEAT_ID, ON_REPEAT_LIMIT,
    ON_REPEAT_WINDOW_SECS,
};

type St<'a> = State<'a, Arc<AppState>>;

/// `record_history`: true only for a query the user submitted. A typeahead preview passes false and
/// goes out unauthenticated, so half-typed prefixes never reach the account's search history (#203).
#[tauri::command]
pub async fn search(
    state: St<'_>,
    query: String,
    record_history: bool,
) -> Result<Vec<SongItem>, String> {
    let client = state.clients.get(innertube::METADATA_CLIENT).ok_or("metadata client missing")?;
    let result =
        state.it.search_songs(client, &query, record_history).await.map_err(|e| e.to_string())?;
    Ok(result.items)
}

/// Search video uploads only: the Videos shelf and its "Show more" page (#209, #266). Never
/// records history, the page's other searches already did.
#[tauri::command]
pub async fn search_videos(state: St<'_>, query: String) -> Result<Vec<SongItem>, String> {
    let client = metadata_client(&state)?;
    let result = state.it.search_videos(client, &query).await.map_err(|e| e.to_string())?;
    Ok(result.items)
}

/// One song or video by id, for a pasted YouTube link (#441). `/next` is the one call that answers
/// with the id's own title, artists and art; the seed comes back as one of its rows.
#[tauri::command]
pub async fn song(state: St<'_>, video_id: String) -> Result<SongItem, String> {
    let client = metadata_client(&state)?;
    let next = state.it.next(client, Some(&video_id), None).await.map_err(|e| e.to_string())?;
    next.items.into_iter().find(|i| i.video_id == video_id).ok_or_else(|| "not_found".into())
}

/// Unfiltered search → categorized sections for the search page. `record_history` as in [`search`].
#[tauri::command]
pub async fn search_all(
    state: St<'_>,
    query: String,
    record_history: bool,
) -> Result<SearchResults, String> {
    let client = metadata_client(&state)?;
    state.it.search_all(client, &query, record_history).await.map_err(|e| e.to_string())
}

/// Typeahead completions + a few matching rows, signed in (see `InnerTube::search_suggestions`).
#[tauri::command]
pub async fn search_suggestions(state: St<'_>, query: String) -> Result<SearchSuggestions, String> {
    let client = metadata_client(&state)?;
    state.it.search_suggestions(client, &query).await.map_err(|e| e.to_string())
}

/// Filtered "Show more" search for one category (albums / artists / playlists).
#[tauri::command]
pub async fn search_cards(
    state: St<'_>,
    query: String,
    category: String,
) -> Result<Vec<BrowseItem>, String> {
    let client = metadata_client(&state)?;
    state.it.search_cards(client, &query, &category).await.map_err(|e| e.to_string())
}

/// Play a track (from a search result). The UI passes the full item so we can seed the queue
/// with its metadata without another round-trip.
#[tauri::command]
pub async fn play(state: St<'_>, item: SongItem) -> Result<(), String> {
    let state = state.inner().clone();
    state.play_song(item).await;
    Ok(())
}

#[tauri::command]
pub async fn play_index(state: St<'_>, index: usize) -> Result<(), String> {
    let state = state.inner().clone();
    state.play_index(index).await;
    Ok(())
}

/// The player view's Song/Video switch: the playing track's other version, same position (#442).
#[tauri::command]
pub async fn switch_version(state: St<'_>) -> Result<(), String> {
    let state = state.inner().clone();
    state.switch_version().await;
    Ok(())
}

/// Remove an upcoming track from the queue (not the one playing). Guests are add-only — blocked
/// inside AppState.
#[tauri::command]
pub async fn remove_from_queue(state: St<'_>, index: usize) -> Result<(), String> {
    state.inner().clone().remove_from_queue(index).await;
    Ok(())
}

/// "Play next" from a ⋯ menu: one track or a whole album/playlist, inserted right after the
/// current song (behind any earlier manual adds). `from` is the album/playlist title, which heads
/// the block in the queue panel.
#[tauri::command]
pub async fn play_next(
    state: St<'_>,
    items: Vec<SongItem>,
    from: Option<String>,
) -> Result<(), String> {
    state.inner().clone().play_next(items, from).await;
    Ok(())
}

/// Drag-to-reorder in the queue panel: move the upcoming track at `from` to `to`. Out-of-range or
/// already-played indices are ignored.
#[tauri::command]
pub async fn move_in_queue(state: St<'_>, from: usize, to: usize) -> Result<(), String> {
    state.inner().clone().move_in_queue(from, to).await;
    Ok(())
}

/// "Add to queue": the tracks go at the back of the "Next in queue" block, so they play after
/// everything already queued by hand and ahead of the playing context (and its radio/filler).
/// `from` heads the block in the queue panel; `continuation` is the source page's next-page token —
/// the rest of a long playlist is walked in in the background.
#[tauri::command]
pub async fn add_to_queue(
    state: St<'_>,
    items: Vec<SongItem>,
    from: Option<String>,
    continuation: Option<String>,
) -> Result<(), String> {
    state.inner().clone().add_to_queue(items, from, continuation).await;
    Ok(())
}

/// Clear every upcoming manually-queued track (the queue panel's "Next in queue" section).
#[tauri::command]
pub async fn clear_queued(state: St<'_>) -> Result<(), String> {
    state.inner().clone().clear_queued().await;
    Ok(())
}

#[tauri::command]
pub async fn next_track(state: St<'_>) -> Result<(), String> {
    state.inner().clone().next_in_queue().await;
    Ok(())
}

#[tauri::command]
pub async fn prev_track(state: St<'_>) -> Result<(), String> {
    state.inner().clone().prev_in_queue().await;
    Ok(())
}

/// The queue panel's "Back to …": put back the queue a click replaced, at the track and position
/// it was left at. Previous does this too, but only from the top of a track; this one is the whole
/// point of the line, so it doesn't rewind first.
#[tauri::command]
pub async fn back_to_previous(state: St<'_>) -> Result<(), String> {
    state.inner().clone().restore_prev_context().await;
    Ok(())
}

#[tauri::command]
pub async fn toggle_shuffle(state: St<'_>) -> Result<(), String> {
    state.inner().clone().toggle_shuffle().await;
    Ok(())
}

/// `mode` ∈ "off" | "all" | "one".
#[tauri::command]
pub async fn set_repeat(state: St<'_>, mode: String) -> Result<(), String> {
    let mode = match mode.as_str() {
        "off" => crate::state::RepeatMode::Off,
        "all" => crate::state::RepeatMode::All,
        "one" => crate::state::RepeatMode::One,
        other => return Err(format!("unknown repeat mode: {other}")),
    };
    state.inner().clone().set_repeat(mode).await;
    Ok(())
}

#[tauri::command]
pub async fn toggle_pause(state: St<'_>) -> Result<(), String> {
    let state = state.inner().clone();
    state.resume_or_toggle().await;
    Ok(())
}

#[tauri::command]
pub async fn seek(state: St<'_>, position: f64) -> Result<(), String> {
    // Routed through AppState so a Listen Together host broadcasts the seek and a guest is blocked.
    state.user_seek(position).await
}

#[tauri::command]
pub async fn set_volume(state: St<'_>, volume: i64) -> Result<(), String> {
    state.player.set_volume(volume).map_err(|e| e.to_string())?;
    if volume > 0 {
        crate::hotkeys::LAST_NONZERO_VOLUME.store(volume, std::sync::atomic::Ordering::Relaxed);
    }
    // There is one volume and there can be two windows (the mini player). Without this the one
    // that didn't move the slider keeps showing the old level and lies about what you're hearing.
    let _ = state.app.emit("volume", volume);
    state.media_set_volume(volume);
    Ok(())
}

/// Session-only tempo (0.5–2.0), pitch (−12..=12 semitones), and reverb controls.
#[tauri::command]
pub async fn set_playback_params(
    state: St<'_>,
    speed: f64,
    semitones: i32,
    reverb: player::Reverb,
) -> Result<(), String> {
    state.set_playback_params(speed, semitones, reverb).await
}

#[tauri::command]
pub async fn get_queue(state: St<'_>) -> Result<serde_json::Value, String> {
    Ok(state.queue_snapshot().await)
}

/// Settings the UI is allowed to read *and write*. Session/auth material (`session_cookie`,
/// `selected_identity_json`, `data_sync_id`, `account_json`, `account_selection_pending`,
/// `visitor_data`) and internal blobs (`queue_json`, `queue_index`, `queue_position`) never cross
/// into the webview: they'd otherwise ship the login credential to the renderer on every open, and
/// the webview can't overwrite them either.
const UI_SETTINGS: [&str; 32] = [
    "volume",
    "proxy",
    "quality",
    "normalize_volume",
    "enable_history",
    "disabled_stream_clients",
    "discord_rpc",
    "discord_rpc_config",
    "close_to_tray",
    "track_notifications",
    "track_notifications_focused",
    "play_on_start",
    "autostart",
    "start_minimized",
    "autoplay",
    "hide_videos",
    "prevent_duplicates",
    "update_banner",
    "update_channel",
    "lyrics_providers",
    "music_videos",
    "videos_first",
    "ambient_light",
    "sticky_shuffle",
    "shuffle_whole_queue",
    "system_titlebar",
    "lastfm_primary_artist",
    "lastfm_primary_strict",
    "lastfm_config",
    "crossfade",
    "crossfade_secs",
    "locale",
];

/// Resolve the music video for `video_id` and hand back a `limusicvideo://` URL the player view
/// can put in a `<video src>`. `None` when YouTube has no usable video stream for it, which is the
/// ordinary answer for a song and leaves the artwork in place. The real googlevideo URL never
/// leaves Rust (context/11).
#[tauri::command]
pub async fn video_stream(
    state: St<'_>,
    video_id: String,
    max_height: i32,
) -> Result<Option<String>, String> {
    if crate::local::is_local_song(&video_id) {
        return Ok(None);
    }
    // Already resolved and still live: the loopback URL is a pure function of the videoId, so
    // there is nothing left to do. Re-resolving costs up to two `/player` round trips, and the
    // player view pays them on every reopen otherwise.
    if state.video_url(&video_id).is_some() {
        return Ok(crate::videoproxy::url_for(&video_id));
    }
    // The webview picks the height from its own box, so clamp it here rather than trusting it.
    let max_height = max_height.clamp(144, 1080);
    match state.orchestrator.resolve_video(&video_id, max_height, &state.disabled_clients()).await {
        Some(url) => {
            state.put_video_url(&video_id, url);
            Ok(crate::videoproxy::url_for(&video_id))
        }
        None => Ok(None),
    }
}

/// The glow around the music video, where mpv draws the picture (Linux): the newest small frame
/// other than `after` (nativevideo.rs has the layout), or nothing if none came within a quarter
/// second. Raw bytes, so the ~22 KB a frame skips JSON both ways.
#[tauri::command]
pub async fn ambient_frame(after: u32) -> tauri::ipc::Response {
    #[cfg(any(target_os = "linux", windows))]
    let frame = crate::nativevideo::next_frame(after).await.map(|f| f.to_vec());
    // Typed: on macOS a bare `None` leaves nothing to infer from, and the PR checks only build on
    // Linux, so this broke rc.3's Windows and macOS builds with every check green.
    #[cfg(not(any(target_os = "linux", windows)))]
    let frame: Option<Vec<u8>> = {
        let _ = after;
        None
    };
    tauri::ipc::Response::new(frame.unwrap_or_default())
}

/// Where the page's hole for the music video is (`[x, y, w, h]`, CSS pixels, viewport-relative),
/// or `None` when it has none. mpv draws the picture there, underneath the webview
/// (nativevideo.rs, nativevideo_windows.rs). `false` means no picture is up, and for a rect that
/// there never will be: the page falls back to the `<video>` element. `dpr` is the page's
/// `devicePixelRatio`, which Windows needs for the page zoom; Linux reads the zoom off the webview.
#[tauri::command]
pub async fn native_video_rect(
    app: tauri::AppHandle,
    state: St<'_>,
    rect: Option<[f64; 4]>,
    dpr: Option<f64>,
) -> Result<bool, String> {
    #[cfg(target_os = "linux")]
    {
        let _ = dpr;
        Ok(crate::nativevideo::set_rect(&app, state.inner().clone(), rect).await)
    }
    #[cfg(windows)]
    return Ok(
        crate::nativevideo::set_rect(&app, state.inner().clone(), rect, dpr.unwrap_or(1.0)).await
    );
    #[cfg(not(any(target_os = "linux", windows)))]
    {
        let _ = (app, state, rect, dpr);
        Ok(false)
    }
}

/// Forget a resolved music-video URL, so the next `video_stream` for this id resolves a fresh one.
/// The player view calls this when the `<video>` element fails to load, which is what an expired
/// or revoked googlevideo link looks like from the webview. It also sends that track's next resolve
/// to VISIONOS first, so a WEB_REMIX URL that failed is not rebuilt from the same reply.
#[tauri::command]
pub async fn forget_video_stream(state: St<'_>, video_id: String) -> Result<(), String> {
    state.forget_video_url(&video_id);
    state.orchestrator.mark_video_failed(&video_id);
    Ok(())
}

/// Who draws the window frame, as the SPA needs to know it (issue #65). Read-only, derived: the
/// stored `system_titlebar` preference on Linux/Windows, and always `overlay` on macOS, where the
/// traffic lights come from `tauri.macos.conf.json`'s `titleBarStyle: Overlay` and there is no
/// preference to make. Anything but `off` means the app hides its own window buttons, drops its
/// corner rounding and leaves resizing to the compositor.
fn native_chrome(db: &crate::db::Db) -> &'static str {
    if cfg!(target_os = "macos") {
        "overlay"
    } else if db.get_setting("system_titlebar").as_deref() == Some("true") {
        "on"
    } else {
        "off"
    }
}

/// GTK's `gtk-decoration-layout` (`menu:close`, `:minimize,maximize,close`), read once on the main
/// thread in `setup`. Linux only: the titlebar draws minimize and maximize only when it names
/// them, as GTK's own headerbars do (#481). Tiling compositors (Hyprland, sway, niri) ignore
/// minimize and often drop maximize, and their unconfigured layout is `menu:close`.
pub static BUTTON_LAYOUT: std::sync::OnceLock<String> = std::sync::OnceLock::new();

#[tauri::command]
pub async fn get_settings(state: St<'_>) -> Result<serde_json::Value, String> {
    let mut map: serde_json::Map<String, serde_json::Value> = state
        .db
        .all_settings()
        .into_iter()
        .filter(|(k, _)| UI_SETTINGS.contains(&k.as_str()))
        .map(|(k, v)| (k, serde_json::Value::String(v)))
        .collect();
    map.insert("native_chrome".into(), native_chrome(&state.db).into());
    // Windows 11 rounds an undecorated window with a shadow (our main window) by itself, so the
    // SPA's own rounding would leave transparent slivers inside DWM's curve (#504). Windows 10
    // rounds nothing, and square is its native corner anyway.
    map.insert("os_corners".into(), cfg!(target_os = "windows").to_string().into());
    map.insert("native_video".into(), crate::state::native_video().to_string().into());
    if let Some(layout) = BUTTON_LAYOUT.get() {
        map.insert("button_layout".into(), layout.clone().into());
    }
    Ok(serde_json::Value::Object(map))
}

#[tauri::command]
pub async fn set_setting(
    app: tauri::AppHandle,
    state: St<'_>,
    key: String,
    value: String,
) -> Result<(), String> {
    if !UI_SETTINGS.contains(&key.as_str()) {
        return Err(format!("unknown setting: {key}"));
    }
    // Registers/removes the login autostart entry on toggle; the OS persists it from there, and
    // startup repoints an existing entry at the running binary (lib.rs). Before the write, so a
    // failure leaves the setting as it was. A dev build would register itself, and at login its
    // window needs a vite server that isn't running.
    if key == "autostart" {
        if tauri::is_dev() {
            return Err(
                "autostart: a dev build can't register itself, use an installed build".into()
            );
        }
        use tauri_plugin_autostart::ManagerExt;
        let al = app.autolaunch();
        let res = if value == "true" {
            al.enable()
        } else if al.is_enabled().unwrap_or(false) {
            al.disable()
        } else {
            Ok(())
        };
        res.map_err(|e| format!("autostart: {e}"))?;
    }
    state.db.set_setting(&key, &value);
    // A music video track already playing gets its picture now rather than from the next track.
    if key == "music_videos" && value == "true" {
        state.inner().attach_current_video().await;
    }
    // And the rest of the queue moves to the version the settings now pick.
    if key == "music_videos" || key == "videos_first" {
        state.inner().apply_version_preference().await;
    }
    #[cfg(target_os = "linux")]
    if key == "ambient_light" {
        crate::set_webgl(&app, value == "true");
    }
    // Presence connects/clears the moment it's toggled — the user shouldn't have to skip a track
    // to see it take effect.
    if key == "discord_rpc" {
        state.set_discord_enabled(value == "true");
    }
    // Same reasoning for the card layout: the settings tab previews it live, so the real card has
    // to follow without waiting for the next track.
    if key == "discord_rpc_config" {
        state.set_discord_config(&value);
    }
    // The Scrobbling tab's settings, read whole each time: the two switches from #231 keep rows of
    // their own, and the scrobbler wants all of it in one message.
    if matches!(key.as_str(), "lastfm_config" | "lastfm_primary_artist" | "lastfm_primary_strict") {
        state.lastfm.set_config(crate::lastfm::ScrobbleConfig::load(&state.db));
    }
    // Retune the track that's playing. Unlike crossfade below, this one has to apply to what the
    // user is hearing right now: the switch exists so they can A/B the same loud section (#298).
    if key == "normalize_volume" {
        state.reapply_gain().await;
    }
    // The queue panel's switch sits right above the tracks it adds, so they come and go with it.
    // Spawned: turning it on can mean a radio fetch, and the switch shouldn't wait on the network.
    if key == "autoplay" {
        let (state, on) = (state.inner().clone(), value != "false");
        tauri::async_runtime::spawn(async move { state.autoplay_changed(on).await });
    }
    // Both halves are one player setting. Applies from the next track change: the transition the
    // user is already hearing keeps the length it started with.
    if key == "crossfade" || key == "crossfade_secs" {
        state.apply_crossfade().await;
    }
    // The language YouTube answers in (#274). The SPA writes it whenever the two disagree, which is
    // also how a fresh install's language gets here at all. It drops its own browse cache and
    // remounts the route afterwards, so what is already on screen follows without a restart.
    if key == "locale" {
        state.it.set_locale(&value);
    }
    // Applies to what's fetched from here on: the live queue keeps whatever is already in it.
    if key == "hide_videos" {
        state.it.set_hide_videos(value == "true");
    }
    // Cached lyrics outlive the order that produced them, so a reorder would otherwise reach only
    // songs never played. Songs whose source was picked by hand keep it.
    if key == "lyrics_providers" {
        state.db.clear_lyrics_cache();
    }
    // Hand the frame back to the compositor (or take it again). macOS is not on this path: its
    // titlebar style is fixed at window creation, so the setting is hidden there.
    #[cfg(not(target_os = "macos"))]
    if key == "system_titlebar" {
        use tauri::Manager;
        if let Some(w) = app.get_webview_window("main") {
            w.set_decorations(value == "true").map_err(|e| format!("decorations: {e}"))?;
        }
    }
    Ok(())
}

#[tauri::command]
pub async fn get_global_hotkeys(
    hotkeys: State<'_, Arc<crate::hotkeys::HotkeysManager>>,
) -> Result<crate::hotkeys::HotkeysConfig, String> {
    Ok(hotkeys.get_config())
}

/// A Wayland session, where the X11 grab the hotkeys use only fires if the compositor passes keys
/// on to XWayland (KDE Plasma does, GNOME does not). The GDK backend doesn't matter, the session does.
#[tauri::command]
pub fn global_hotkeys_on_wayland() -> bool {
    cfg!(target_os = "linux") && std::env::var_os("WAYLAND_DISPLAY").is_some()
}

#[tauri::command]
pub async fn set_global_hotkeys(
    app: tauri::AppHandle,
    state: St<'_>,
    hotkeys: State<'_, Arc<crate::hotkeys::HotkeysManager>>,
    config: crate::hotkeys::HotkeysConfig,
) -> Result<crate::hotkeys::HotkeyRegisterResult, String> {
    let result = hotkeys.apply_config(&app, config);
    // Saved even on partial failure: apply_config already made this the live config, and a
    // combo another app holds shouldn't cost the user every other binding on the next launch.
    crate::hotkeys::save_config(&state.db, &result.config);
    Ok(result)
}

#[tauri::command]
pub async fn reset_global_hotkeys(
    app: tauri::AppHandle,
    state: St<'_>,
    hotkeys: State<'_, Arc<crate::hotkeys::HotkeysManager>>,
) -> Result<crate::hotkeys::HotkeyRegisterResult, String> {
    // Resets the bindings only: the default has hotkeys off, and the button is on the enabled page.
    let default_config = crate::hotkeys::HotkeysConfig {
        enabled: hotkeys.get_config().enabled,
        ..Default::default()
    };
    let result = hotkeys.apply_config(&app, default_config);
    crate::hotkeys::save_config(&state.db, &result.config);
    Ok(result)
}

/// The streamable client keys the orchestrator tries, for the "disabled clients" setting. Names
/// come from the innertube crate so the UI stays free of YouTube-shaped identity strings.
#[tauri::command]
pub async fn get_stream_clients() -> Result<Vec<String>, String> {
    let mut v = vec![innertube::MAIN_CLIENT.to_string()];
    v.extend(innertube::STREAM_FALLBACK_ORDER.iter().map(|s| s.to_string()));
    Ok(v)
}

/// Let the webview fetch one font file the user picked in the Themes tab, so a `@font-face` can
/// point at it.
///
/// Same runtime-scope trick as local artwork (`local::allow_covers`): the static asset scope stays
/// empty, and only the exact file gets a URL. The extension check keeps the command from being a
/// general "give the page a URL for any path on this machine" — today only the main window holds a
/// capability to call commands at all, and this stays safe if that ever widens.
#[tauri::command]
pub async fn allow_font_file(app: tauri::AppHandle, path: String) -> Result<(), String> {
    use tauri::Manager;
    const FONT_EXTS: [&str; 4] = ["ttf", "otf", "woff", "woff2"];
    let p = std::path::Path::new(&path);
    let ext = p.extension().and_then(|e| e.to_str()).unwrap_or_default().to_ascii_lowercase();
    if !FONT_EXTS.contains(&ext.as_str()) {
        return Err(format!("not a font file: {path}"));
    }
    // Scope grants succeed for paths that don't exist, so check here: this failing is how the UI
    // learns a loaded font was deleted or moved, and drops it instead of listing a dead entry.
    if !p.is_file() {
        return Err(format!("font file not found: {path}"));
    }
    let scope = app.asset_protocol_scope();
    scope.allow_file(&path).map_err(|e| e.to_string())?;
    // The scope check canonicalizes what it is asked about, so a font reached through a symlinked
    // folder needs the real path allowed too (see local::allow_covers).
    if let Ok(real) = p.canonicalize() {
        let _ = scope.allow_file(real);
    }
    Ok(())
}

// --- app icon (#173) -------------------------------------------------------------------------

/// Set the app icon to a PNG the user picked, or clear it back to the bundled one with `None`.
/// The file is copied rather than referenced (see appicon.rs).
#[tauri::command]
pub async fn set_app_icon(app: tauri::AppHandle, path: Option<String>) -> Result<(), String> {
    let dest = crate::appicon::path(&app).ok_or("no app data directory")?;
    match path {
        Some(src) => {
            // `from_path` reads and decodes the whole file, so bound it first: a compressed
            // 16 MB of uniform 8192x8192 still unpacks into 256 MB before anything can reject it.
            // The signature and IHDR are the first 24 bytes of any PNG.
            let len =
                std::fs::metadata(&src).map_err(|e| format!("couldn't read that PNG: {e}"))?.len();
            if len > 16 * 1024 * 1024 {
                return Err("that file is too big; use a PNG under 16 MB".into());
            }
            let mut head = [0u8; 24];
            {
                use std::io::Read;
                std::fs::File::open(&src)
                    .and_then(|mut f| f.read_exact(&mut head))
                    .map_err(|e| format!("couldn't read that PNG: {e}"))?;
            }
            if head[..8] != *b"\x89PNG\r\n\x1a\n" {
                return Err("that file isn't a PNG".into());
            }
            let width = u32::from_be_bytes([head[16], head[17], head[18], head[19]]);
            let height = u32::from_be_bytes([head[20], head[21], head[22], head[23]]);
            // Nothing draws an icon above 256px, and every launch would pay to decode whatever
            // was picked: a 5000px photo is a 100 MB buffer for a 16px titlebar logo.
            if width > 1024 || height > 1024 {
                return Err(format!(
                    "that image is {width}x{height}; use one no larger than 1024x1024"
                ));
            }
            // Decoding it here is the validation, now bounded to 1024x1024. Storing a file the
            // icon loader can't read would fail silently at every launch instead, with the old
            // icon still showing.
            tauri::image::Image::from_path(&src)
                .map_err(|e| format!("couldn't read that PNG: {e}"))?;
            if let Some(dir) = dest.parent() {
                std::fs::create_dir_all(dir).map_err(|e| format!("couldn't save the icon: {e}"))?;
            }
            // Copy beside the destination and rename over it. `fs::copy` truncates the old file
            // before writing, so a failure part way through would leave a half-written PNG that
            // every later launch still treats as the custom icon.
            let tmp = dest.with_extension("png.tmp");
            std::fs::copy(&src, &tmp).and_then(|_| std::fs::rename(&tmp, &dest)).map_err(|e| {
                let _ = std::fs::remove_file(&tmp);
                format!("couldn't save the icon: {e}")
            })?;
        }
        None => match std::fs::remove_file(&dest) {
            Ok(()) => {}
            // Already gone is the state the caller asked for; anything else means the custom icon
            // is still on disk and `apply` below would just put it back.
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => {}
            Err(e) => return Err(format!("couldn't remove the icon: {e}")),
        },
    }
    crate::appicon::apply(&app);
    Ok(())
}

/// The custom icon's path, granted to the asset protocol so the in-app logo can render it. `None`
/// when the bundled icon is in use.
#[tauri::command]
pub async fn app_icon_path(app: tauri::AppHandle) -> Result<Option<String>, String> {
    use tauri::Manager;
    let Some(p) = crate::appicon::custom_path(&app) else { return Ok(None) };
    let scope = app.asset_protocol_scope();
    scope.allow_file(&p).map_err(|e| e.to_string())?;
    // Same symlink dance as the font grant: the scope check canonicalizes what it is asked about.
    if let Ok(real) = p.canonicalize() {
        let _ = scope.allow_file(real);
    }
    Ok(Some(p.to_string_lossy().into_owned()))
}

/// Wipe both cache tiers (URL cache + mpv on-disk audio cache). context/14.
#[tauri::command]
pub async fn clear_caches(state: St<'_>) -> Result<(), String> {
    state.clear_caches();
    Ok(())
}

// --- auth (context/15) ---------------------------------------------------------------------

#[tauri::command]
pub async fn get_account(state: St<'_>) -> Result<serde_json::Value, String> {
    Ok(state.account_snapshot())
}

#[tauri::command]
pub async fn get_account_identities(state: St<'_>) -> Result<Vec<serde_json::Value>, String> {
    state.account_identities().await
}

#[tauri::command]
pub async fn switch_account(
    state: St<'_>,
    selection_key: String,
) -> Result<serde_json::Value, String> {
    state.switch_account(&selection_key).await
}

#[tauri::command]
pub async fn sign_out(state: St<'_>) -> Result<(), String> {
    let state = state.inner().clone();
    state.sign_out().await;
    Ok(())
}

// --- saved Google accounts (multi-account, context/15) ---------------------------------------

/// Saved Google accounts for the account menu. Display fields only — cookies, delegated ids and
/// visitorData never cross the Tauri boundary.
#[tauri::command]
pub async fn get_google_accounts(state: St<'_>) -> Result<Vec<serde_json::Value>, String> {
    Ok(state.google_accounts())
}

/// Activate a saved Google account without a Google re-login. Fails if the stored cookie no
/// longer authenticates, in which case the caller should re-sign-in with that account.
#[tauri::command]
pub async fn switch_google_account(state: St<'_>, id: String) -> Result<serde_json::Value, String> {
    state.switch_google_account(&id).await
}

/// Delete a saved account. Removing the active one signs out; the others stay listed.
#[tauri::command]
pub async fn remove_google_account(state: St<'_>, id: String) -> Result<(), String> {
    state.remove_google_account(&id).await;
    Ok(())
}

/// Open the in-app Google sign-in webview (context/15 Path A). Completes asynchronously; the UI
/// hears back via `auth-changed` (success) or `login-error`. With `add_account`, the webview
/// opens Google's AddSession screen so a second account can be added even when the webview
/// already holds a Google session.
#[tauri::command]
pub async fn login_webview(state: St<'_>, add_account: Option<bool>) -> Result<(), String> {
    let state = state.inner().clone();
    let app = state.app.clone();
    crate::session::open_login(app, state, add_account.unwrap_or(false));
    Ok(())
}

/// The current track, play state, position and duration in one shot. Events are the normal
/// channel; this is for a webview that started after them (the mini player, or the main window
/// on a cold start, where the queue is restored before the UI subscribes).
#[tauri::command]
pub async fn get_playback(state: St<'_>) -> Result<serde_json::Value, String> {
    Ok(state.playback_snapshot().await)
}

// --- mini player (mini.rs) ------------------------------------------------------------------

/// Swap the app for the floating widget: the main window hides to the tray behind it.
#[tauri::command]
pub async fn open_mini(app: tauri::AppHandle) -> Result<(), String> {
    // GTK wants window creation on the main thread, so hop and post the result back rather than
    // logging a failure the user would only see as a click that did nothing.
    let (tx, rx) = tokio::sync::oneshot::channel();
    let handle = app.clone();
    app.run_on_main_thread(move || {
        let _ = tx.send(crate::mini::open(&handle));
    })
    .map_err(|e| e.to_string())?;
    rx.await.map_err(|_| "the mini player never answered".to_string())?
}

/// Swap back. Same path as the tray, so the widget and the tray can't disagree about what
/// "show Limusic" means.
#[tauri::command]
pub async fn close_mini(app: tauri::AppHandle) -> Result<(), String> {
    crate::tray::show_main(&app);
    Ok(())
}

/// The widget's shrink/expand button (#301).
#[tauri::command]
pub async fn set_mini_compact(app: tauri::AppHandle, compact: bool) -> Result<(), String> {
    crate::mini::set_compact(&app, compact)
}

/// The arguments this process was launched with, handed over once (#348). See `LAUNCH_ARGS`.
#[tauri::command]
pub fn take_launch_args() -> Vec<String> {
    std::mem::take(&mut *crate::LAUNCH_ARGS.lock().unwrap())
}

#[tauri::command]
pub async fn show_main(state: St<'_>, window: tauri::WebviewWindow) -> Result<bool, String> {
    crate::UI_MOUNTED.notify_one();
    if crate::should_start_minimized(&state.db) {
        return Ok(false);
    }
    window.show().map_err(|e| e.to_string())?;
    window.unminimize().map_err(|e| e.to_string())?;
    window.set_focus().map_err(|e| e.to_string())?;
    crate::tray::set_main_visible(window.app_handle(), true);
    Ok(true)
}

// --- browse / library (context/08) ---------------------------------------------------------

fn metadata_client(state: &Arc<AppState>) -> Result<&innertube::YouTubeClient, String> {
    state.clients.get(innertube::METADATA_CLIENT).ok_or_else(|| "metadata client missing".into())
}

#[tauri::command]
pub async fn get_home(state: St<'_>, params: Option<String>) -> Result<HomePage, String> {
    let client = metadata_client(&state)?;
    state.it.home(client, params.as_deref()).await.map_err(|e| e.to_string())
}

#[tauri::command]
pub async fn get_home_more(state: St<'_>, token: String) -> Result<HomePage, String> {
    let client = metadata_client(&state)?;
    state.it.home_continuation(client, &token).await.map_err(|e| e.to_string())
}

/// Whether YouTube Music answers at all, for the UI's offline retries (#483): it asks this until
/// the answer is yes and only then reloads the page, so a dead connection doesn't flash skeletons
/// on every try. Any status counts, only getting no reply means the network is still down.
#[tauri::command]
pub async fn network_reachable() -> bool {
    crate::http::network_reachable().await
}

/// Why a comments command failed, as a stable word the UI words itself. Details go to the debug log.
#[derive(Debug, Clone, Copy, serde::Serialize)]
#[serde(rename_all = "snake_case")]
pub enum CommentsError {
    /// The comments belong to a session that is gone (another account, signed out, or a token
    /// from before the last reload): reload them.
    AccountChanged,
    /// Another action on the same comment is still running.
    Busy,
    /// YouTube answered and did not accept it.
    Rejected,
    /// YouTube answered 404: the comment no longer exists.
    Gone,
    /// A post or reply that may have gone through (`Error::WriteUncertain`).
    Uncertain,
    /// Anything else: network, refusals, an unreadable answer, an action not on offer.
    Failed,
}

impl CommentsError {
    /// Classify an innertube error, logging it (its text holds no token or account data).
    fn of(e: &innertube::Error) -> Self {
        tracing::debug!(error = %e, "comments command failed");
        match e {
            innertube::Error::AccountChanged => CommentsError::AccountChanged,
            innertube::Error::ActionRejected => CommentsError::Rejected,
            innertube::Error::WriteUncertain => CommentsError::Uncertain,
            _ => CommentsError::Failed,
        }
    }

    /// [`Self::of`] for a request about one comment, where a 404 means it is gone. `kind` names
    /// the request in the log.
    fn of_comment(e: &innertube::Error, kind: &'static str) -> Self {
        if e.is_not_found() {
            tracing::debug!(kind, "comment request: the comment no longer exists (404)");
            CommentsError::Gone
        } else {
            tracing::debug!(kind, "comment request failed");
            Self::of(e)
        }
    }
}

impl From<String> for CommentsError {
    /// The helpers shared with the other commands report plain strings; here that is a failure.
    fn from(e: String) -> Self {
        tracing::debug!(error = %e, "comments command failed");
        CommentsError::Failed
    }
}

impl From<ActionError> for CommentsError {
    fn from(e: ActionError) -> Self {
        match e {
            ActionError::Unknown => CommentsError::AccountChanged,
            ActionError::Busy => CommentsError::Busy,
            ActionError::Unavailable => CommentsError::Failed,
        }
    }
}

/// First page of comments for a video (see `InnerTube::comments`). Starts a new session: every
/// token on the page is remembered with who it was issued to.
#[tauri::command]
pub async fn get_comments(state: St<'_>, video_id: String) -> Result<CommentsPage, CommentsError> {
    let client = metadata_client(&state)?;
    let epoch = {
        let mut session = state.comments.lock().unwrap();
        session.start(&video_id);
        session.epoch()
    };
    let before = state.it.comments_identity();
    let page = state.it.comments(client, &video_id).await.map_err(|e| CommentsError::of(&e))?;
    let provenance = if page.read_as_account {
        // If the account changed during the read, the page belongs to nobody signed in now.
        match (before, state.it.comments_identity()) {
            (Some(was), Some(is)) if was == is => Provenance::Account(is),
            _ => return Err(CommentsError::AccountChanged),
        }
    } else {
        Provenance::Anonymous
    };
    remember_read(&state, epoch, |s| s.remember_page(&provenance, &page))?;
    Ok(page)
}

/// Remember what a read returned, unless the session was cleared while it was in flight (another
/// track or an auth change): then the answer belongs to comments that are gone, and the UI reloads.
fn remember_read(
    state: &AppState,
    epoch: u64,
    remember: impl FnOnce(&mut innertube::CommentsSession),
) -> Result<(), CommentsError> {
    let mut session = state.comments.lock().unwrap();
    if session.epoch() != epoch {
        tracing::debug!("comments read: the session was cleared during it");
        return Err(CommentsError::AccountChanged);
    }
    remember(&mut session);
    Ok(())
}

/// How a token goes back: the way it was issued, and an account's only while that account is active.
fn comments_token_origin(
    state: &Arc<AppState>,
    token: &str,
) -> Result<(Provenance, bool), CommentsError> {
    let origin = state.comments.lock().unwrap().provenance(token);
    match origin {
        None => Err(CommentsError::AccountChanged),
        Some(Provenance::Anonymous) => Ok((Provenance::Anonymous, false)),
        Some(Provenance::Account(who)) => {
            if state.it.comments_identity().as_deref() == Some(who.as_str()) {
                Ok((Provenance::Account(who), true))
            } else {
                Err(CommentsError::AccountChanged)
            }
        }
    }
}

/// Next page of comments, or the same comments in another order: pagination tokens and the
/// header's sort tokens both load through here.
#[tauri::command]
pub async fn get_comments_more(
    state: St<'_>,
    token: String,
) -> Result<CommentsPage, CommentsError> {
    let client = metadata_client(&state)?;
    let epoch = state.comments.lock().unwrap().epoch();
    let (provenance, as_account) = comments_token_origin(&state, &token)?;
    let page = state
        .it
        .comments_continuation(client, &token, as_account)
        .await
        .map_err(|e| CommentsError::of(&e))?;
    remember_read(&state, epoch, |s| s.remember_page(&provenance, &page))?;
    Ok(page)
}

/// A page of one thread's replies, with the token for the next page when there is one.
#[tauri::command]
pub async fn get_comment_replies(
    state: St<'_>,
    token: String,
) -> Result<CommentReplies, CommentsError> {
    let client = metadata_client(&state)?;
    let epoch = state.comments.lock().unwrap().epoch();
    let (provenance, as_account) = comments_token_origin(&state, &token)?;
    let replies = state
        .it
        .comment_replies(client, &token, as_account)
        .await
        .map_err(|e| CommentsError::of(&e))?;
    remember_read(&state, epoch, |s| s.remember_replies(&provenance, &replies))?;
    Ok(replies)
}

/// A comment after an accepted action. No counts: the UI swaps the two it already has.
#[derive(serde::Serialize)]
pub struct CommentActionOutcome {
    pub vote: VoteState,
    /// What the comment offers next, which may be nothing.
    pub actions: Vec<CommentAction>,
}

/// Like, unlike, dislike or undislike one comment. The token is looked up here under the active
/// account, and only if the comment offers that action.
#[tauri::command]
pub async fn comment_action(
    state: St<'_>,
    comment_id: String,
    action: CommentAction,
) -> Result<CommentActionOutcome, CommentsError> {
    // Nobody signed in (any more) is the same as a changed account: reload the comments.
    let client = require_login(&state).map_err(|_| CommentsError::AccountChanged)?;
    let identity = state.it.comments_identity().ok_or(CommentsError::AccountChanged)?;
    let ticket = state.comments.lock().unwrap().begin_action(&identity, &comment_id, action)?;
    let sent = state.it.comment_action(client, ticket.token(), action.name()).await;
    // Under the identity it was sent as, whoever is active now.
    let accepted = sent.is_ok().then_some(ticket.resulting_vote);
    let after = state.comments.lock().unwrap().finish_action(&identity, &comment_id, accepted);
    if sent.as_ref().err().is_some_and(innertube::Error::is_not_found) {
        // The comment is gone: nothing may be sent for it again.
        state.comments.lock().unwrap().forget(&identity, &comment_id);
    }
    sent.map_err(|e| CommentsError::of_comment(&e, action.name()))?;
    Ok(CommentActionOutcome {
        vote: ticket.resulting_vote,
        actions: after.map(|(_, actions)| actions).unwrap_or_default(),
    })
}

// --- writing comments: replay the command the active account's read issued (see
// `innertube::WriteCommand`); the UI sends only the comment id and the text. ---------------

/// The text of a comment about to be sent: trimmed, and not empty.
fn comment_text(text: &str) -> Result<&str, CommentsError> {
    let text = text.trim();
    if text.is_empty() {
        Err(CommentsError::Failed)
    } else {
        Ok(text)
    }
}

/// Reply, edit or delete one comment. The answer is returned for a reply to be looked at.
async fn write_on_comment(
    state: &Arc<AppState>,
    comment_id: &str,
    write: CommentWrite,
    text: Option<&str>,
) -> Result<(serde_json::Value, String), CommentsError> {
    // Nobody signed in (any more) is the same as a changed account: reload the comments.
    let client = require_login(state).map_err(|_| CommentsError::AccountChanged)?;
    let identity = state.it.comments_identity().ok_or(CommentsError::AccountChanged)?;
    let ticket = state.comments.lock().unwrap().begin_write(&identity, comment_id, write)?;
    let replayable = write != CommentWrite::Reply;
    let sent = state.it.comment_write(client, ticket.command(), text, replayable).await;
    // Under the identity it was sent as. A delete that went through, and a 404, forget the comment.
    let gone = sent.as_ref().err().is_some_and(innertube::Error::is_not_found);
    state.comments.lock().unwrap().finish_write(
        &identity,
        comment_id,
        gone || (sent.is_ok() && write == CommentWrite::Delete),
    );
    let answer = sent.map_err(|e| CommentsError::of_comment(&e, ticket.command().log_kind()))?;
    Ok((answer, identity))
}

/// The comment a post or reply put on the page, if its answer carried it: remembered under the
/// identity that wrote it, so it can be acted on at once.
fn remember_written(
    state: &AppState,
    kind: &'static str,
    identity: String,
    answer: &serde_json::Value,
) -> Option<CommentThread> {
    let thread = innertube::parse_written_comment(answer);
    if let Some(thread) = &thread {
        state.comments.lock().unwrap().remember_thread(&Provenance::Account(identity), thread);
    }
    tracing::debug!(kind, found = thread.is_some(), "comment write: the comment in the answer");
    thread
}

/// Post a top-level comment on `video_id`, the track whose comments the UI shows. Refused, with
/// nothing sent, if the composer was read for another track. Returns the comment when the answer
/// carried it.
#[tauri::command]
pub async fn comment_create(
    state: St<'_>,
    video_id: String,
    text: String,
) -> Result<Option<CommentThread>, CommentsError> {
    let text = comment_text(&text)?;
    let client = require_login(&state).map_err(|_| CommentsError::AccountChanged)?;
    let identity = state.it.comments_identity().ok_or(CommentsError::AccountChanged)?;
    let ticket = state.comments.lock().unwrap().begin_create(&identity, &video_id)?;
    let sent = state.it.comment_write(client, ticket.command(), Some(text), false).await;
    state.comments.lock().unwrap().finish_create(&identity);
    let answer = sent.map_err(|e| CommentsError::of(&e))?;
    Ok(remember_written(&state, "create", identity, &answer))
}

/// Reply to a comment. Returns the reply when the answer carried it.
#[tauri::command]
pub async fn comment_reply(
    state: St<'_>,
    comment_id: String,
    text: String,
) -> Result<Option<Comment>, CommentsError> {
    let text = comment_text(&text)?;
    let (answer, identity) =
        write_on_comment(&state, &comment_id, CommentWrite::Reply, Some(text)).await?;
    Ok(remember_written(&state, "reply", identity, &answer).map(|t| t.comment))
}

/// Replace the text of one of the viewer's own comments.
#[tauri::command]
pub async fn comment_edit(
    state: St<'_>,
    comment_id: String,
    text: String,
) -> Result<(), CommentsError> {
    write_on_comment(&state, &comment_id, CommentWrite::Edit, Some(comment_text(&text)?)).await?;
    Ok(())
}

/// Delete one of the viewer's own comments.
#[tauri::command]
pub async fn comment_delete(state: St<'_>, comment_id: String) -> Result<(), CommentsError> {
    write_on_comment(&state, &comment_id, CommentWrite::Delete, None).await?;
    Ok(())
}

#[tauri::command]
pub async fn get_library(state: St<'_>) -> Result<Vec<BrowseItem>, String> {
    let client = metadata_client(&state)?;
    // Signed out there is no YouTube library to ask for (the browse would come back as a sign-in
    // shell), but On Repeat is built from this machine's play history and is still real.
    let mut items = if state.it.is_logged_in() {
        state.it.library_playlists(client).await.map_err(|e| e.to_string())?
    } else {
        Vec::new()
    };
    // On Repeat leads the library once there's anything in it. Hidden while empty rather than
    // shown as a dead tile on a fresh install.
    let songs = on_repeat_songs(&state);
    if !songs.is_empty() {
        items.insert(
            0,
            BrowseItem {
                kind: "playlist",
                id: ON_REPEAT_ID.into(),
                title: "On Repeat".into(),
                subtitle: Some(format!("{} songs", songs.len())),
                thumbnail: None, // the UI draws an icon cover for this one
                duration: None,
                album_id: None,
                artist_runs: Vec::new(),
                play_count: None,
                is_video: false,
                is_upload: false,
                explicit: false,
            },
        );
    }
    // The playlists on this machine next, signed in or not: they belong to no account.
    let at = usize::from(items.first().is_some_and(|i| i.id == ON_REPEAT_ID));
    let local: Vec<BrowseItem> =
        state.db.local_playlists().iter().map(|p| local_playlist_card(&state, p)).collect();
    items.splice(at..at, local);
    // A card has nowhere to put two images, so a custom cover simply is the artwork here.
    for item in &mut items {
        if let Some(cover) = custom_cover(&state, &item.id) {
            item.thumbnail = Some(cover);
        }
    }
    Ok(items)
}

/// Empty rather than an error when signed out: the Library page merges the user's local saves into
/// these grids, so "nothing of yours on YouTube" is an answer, not a failure.
#[tauri::command]
pub async fn get_library_albums(state: St<'_>) -> Result<Vec<BrowseItem>, String> {
    if !state.it.is_logged_in() {
        return Ok(Vec::new());
    }
    let client = metadata_client(&state)?;
    state.it.library_albums(client).await.map_err(|e| e.to_string())
}

/// The user's own uploaded albums (Library ▸ Uploads ▸ Albums).
#[tauri::command]
pub async fn get_upload_albums(state: St<'_>) -> Result<Vec<BrowseItem>, String> {
    if !state.it.is_logged_in() {
        return Ok(Vec::new());
    }
    let client = metadata_client(&state)?;
    state.it.upload_albums(client).await.map_err(|e| e.to_string())
}

/// The account's YouTube Music play history, grouped by day. Empty when signed out, same as the
/// library grids: history lives on the account, and there is nothing to fail about not having one.
#[tauri::command]
pub async fn get_history(state: St<'_>) -> Result<Vec<HistoryGroup>, String> {
    if !state.it.is_logged_in() {
        return Ok(Vec::new());
    }
    let client = metadata_client(&state)?;
    state.it.history(client).await.map_err(|e| e.to_string())
}

#[tauri::command]
pub async fn get_library_artists(state: St<'_>) -> Result<Vec<BrowseItem>, String> {
    if !state.it.is_logged_in() {
        return Ok(Vec::new());
    }
    let client = metadata_client(&state)?;
    state.it.library_artists(client).await.map_err(|e| e.to_string())
}

#[tauri::command]
pub async fn get_library_subscriptions(state: St<'_>) -> Result<Vec<BrowseItem>, String> {
    if !state.it.is_logged_in() {
        return Ok(Vec::new());
    }
    let client = metadata_client(&state)?;
    state.it.library_subscriptions(client).await.map_err(|e| e.to_string())
}

/// A playlist or album page. `id` is the browseId (`VL…` / `MPRE…`); Liked Songs is `VLLM`, and
/// `LIMUSIC_ON_REPEAT` is the local auto-playlist rather than anything YouTube knows about.
///
/// `sort` asks YouTube for the tracks in a given order; `None` gets whatever order the account
/// already has the list in, which is what a fresh visit wants (it matches YouTube Music).
#[tauri::command]
pub async fn get_playlist(
    state: St<'_>,
    id: String,
    sort: Option<PlaylistSort>,
    desc: Option<bool>,
) -> Result<PlaylistPage, String> {
    if id == ON_REPEAT_ID {
        let items = on_repeat_songs(&state);
        return Ok(PlaylistPage {
            title: Some("On Repeat".into()),
            subtitle: Some(format!("{} songs you've played most this month", items.len())),
            thumbnail: None,
            description: None,
            privacy: None,
            cover: None,
            items,
            continuation: None,
            owned: false, // nothing to rename or delete; it rebuilds itself from what you play
            collaborative: false,
            sort_menu: None, // built from local history, so YouTube has no order to give
            suggestions: None,
        });
    }
    if is_local_playlist(&id) {
        return local_playlist_page(&state, &id);
    }
    let client = metadata_client(&state)?;
    let sort = sort.map(|s| (s, desc.unwrap_or(false)));
    let mut page = state.it.playlist(client, &id, sort).await.map_err(|e| e.to_string())?;
    // Alongside YouTube's own thumbnail, not over it: the dialog offers to drop the custom one.
    page.cover = custom_cover(&state, &id);
    Ok(page)
}

/// Store a sort order on a playlist, so YouTube Music and every other client show it the same way.
///
/// Only for a playlist whose `sortMenu.editable` said the options are writes. Everywhere else the
/// order is view-only and this would 400.
#[tauri::command]
pub async fn set_playlist_sort(
    state: St<'_>,
    playlist_id: String,
    sort: PlaylistSort,
) -> Result<(), String> {
    let client = editable_playlist(&state, &playlist_id)?;
    state.it.playlist_set_sort(client, &playlist_id, sort).await.map_err(|e| e.to_string())
}

/// videoId → how many times it was ever played. Feeds the "Your plays" track column and the
/// playlist page's "Most played" sort, which share it so the sort and the numbers beside it agree;
/// a track the map doesn't mention has never been played.
#[tauri::command]
pub fn play_counts(state: St<'_>) -> std::collections::HashMap<String, i64> {
    state.db.play_counts(0).into_iter().collect()
}

/// The stats page (#396): everything heard since `since` (unix secs, 0 for all time). The page
/// picks the window, because the calendar it is drawn against is the webview's.
#[tauri::command]
pub fn listening_stats(state: St<'_>, since: i64) -> crate::stats::Stats {
    let now = now_secs();
    let since = since.clamp(0, now);
    let raw = state.db.listening(since, now);
    let all_time = !matches!(raw.first_at, Some(first) if since > first);
    let mut stats = crate::stats::shape(raw, all_time);
    for t in &mut stats.top_songs {
        t.song = shed_queue_context(std::mem::take(&mut t.song));
    }
    stats
}

/// Home's Familiar Artists and the community shelf's seed (#497): the `limit` most played artists
/// of all time, on the stats page's counts.
#[tauri::command]
pub fn top_artists(state: St<'_>, limit: usize) -> Vec<crate::stats::TopArtist> {
    crate::stats::top_artists(state.db.listened_songs(0, now_secs()), limit)
}

/// "Clear listening history" on the stats page. On Repeat empties too: it is built from the same
/// plays.
#[tauri::command]
pub fn clear_listening_history(state: St<'_>) {
    state.db.clear_listens();
}

/// The On Repeat track list: most-played first, over the trailing window. Rows whose stored JSON
/// no longer parses (a `SongItem` shape change) are dropped rather than failing the whole page.
fn on_repeat_songs(state: &Arc<AppState>) -> Vec<SongItem> {
    let since = now_secs() - ON_REPEAT_WINDOW_SECS;
    state
        .db
        .top_plays(since, ON_REPEAT_LIMIT)
        .into_iter()
        .filter_map(|(json, _plays)| serde_json::from_str(&json).ok())
        .map(shed_queue_context)
        .collect()
}

/// A play record is the whole `SongItem` as it sat in the queue, so it carries that slot's queue
/// metadata: `queued`/`queued_by` when the track was "added to queue" (in a Listen Together session,
/// stamped with who added it), `autoplay` when radio appended it, `set_video_id` from whatever
/// playlist it was played from. None of that describes the song, so On Repeat sheds it: otherwise
/// the row wears a session member's name forever, and playing On Repeat drops it into "Next in
/// queue" instead of the playlist. Strips on read so rows already stored this way are fixed too.
fn shed_queue_context(s: SongItem) -> SongItem {
    SongItem {
        queued: false,
        queued_end: false,
        queued_from: None,
        queued_by: None,
        autoplay: false,
        set_video_id: None,
        added_by: None,
        added_by_avatars: Vec::new(),
        added_at: None,
        ..s
    }
}

fn now_secs() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0)
}

/// `total` is the playlist's track count, passed by a walk that wants the whole list: it fetches
/// the pages after this one too, several at a time (`InnerTube::playlist_pages`, #536).
#[tauri::command]
pub async fn get_playlist_more(
    state: St<'_>,
    token: String,
    total: Option<usize>,
) -> Result<PlaylistContinuation, String> {
    let client = metadata_client(&state)?;
    match total {
        Some(total) => state.it.playlist_pages(client, &token, total).await,
        None => state.it.playlist_continuation(client, &token).await,
    }
    .map_err(|e| e.to_string())
}

/// A batch of suggestions for a playlist you own (#395). `token` is the page's `suggestions`, the
/// previous batch's `refresh`, or nothing (see `InnerTube::playlist_suggestions`).
#[tauri::command]
pub async fn get_playlist_suggestions(
    state: St<'_>,
    playlist_id: String,
    token: Option<String>,
) -> Result<PlaylistSuggestions, String> {
    let client = metadata_client(&state)?;
    state
        .it
        .playlist_suggestions(client, &playlist_id, token.as_deref())
        .await
        .map_err(|e| e.to_string())
}

/// An album page. `id` is the album browseId (`MPRE…`).
#[tauri::command]
pub async fn get_album(state: St<'_>, id: String) -> Result<AlbumPage, String> {
    // A local album is built from SQLite, so it opens the same page while offline (local.rs).
    if let Some(key) = id.strip_prefix(crate::local::ALBUM_PREFIX) {
        return Ok(crate::local::album_page(&state.db, key));
    }
    // A local artist rides this route too: same page shape, and none of the artist route's
    // YouTube furniture applies to files on disk (see `local::artist_page`).
    if let Some(name) = id.strip_prefix(crate::local::ARTIST_PREFIX) {
        return Ok(crate::local::artist_page(&state.db, name));
    }
    let client = metadata_client(&state)?;
    let mut page = state.it.album(client, &id).await.map_err(|e| e.to_string())?;
    // `album()` hands back the album audio for rows YouTube linked to a music video. With music
    // videos on, those rows play the video, as on YouTube Music, with the song a switch away (#442),
    // unless `videos_first` is off: some videos carry intros and extra scenes the song doesn't (#464).
    let video = crate::state::wants_video(&state.db);
    for item in &mut page.items {
        crate::state::prefer_version(item, video);
    }
    Ok(page)
}

/// An artist page. `id` is the channel browseId (`UC…`).
#[tauri::command]
pub async fn get_artist(state: St<'_>, id: String) -> Result<ArtistPage, String> {
    let client = metadata_client(&state)?;
    state.it.artist(client, &id).await.map_err(|e| e.to_string())
}

/// The artist page's "Appears on" shelf (#456). `songs_id` is the page's `topSongsId`. Its own
/// call so the page paints without waiting on the second browse it costs.
#[tauri::command]
pub async fn get_artist_appears_on(
    state: St<'_>,
    id: String,
    songs_id: String,
) -> Result<Vec<BrowseItem>, String> {
    let client = metadata_client(&state)?;
    state.it.artist_appears_on(client, &id, &songs_id).await.map_err(|e| e.to_string())
}

/// Moods & Genres, the tiles the search page opens on.
#[tauri::command]
pub async fn get_moods(state: St<'_>) -> Result<Vec<MoodSection>, String> {
    let client = metadata_client(&state)?;
    state.it.moods(client).await.map_err(|e| e.to_string())
}

/// A cover for each Moods & Genres tile, which YouTube draws as a coloured button with no art: the
/// first playlist in that tile's category. Six categories at a time. A tile whose category fails
/// or comes back empty is left out, and the page draws it without art. The page keeps what comes
/// back, so this runs once per tile, not once per visit.
#[tauri::command]
pub async fn get_mood_art(
    state: St<'_>,
    params: Vec<String>,
) -> Result<std::collections::HashMap<String, String>, String> {
    use futures_util::StreamExt;
    let client = metadata_client(&state)?;
    let it = &state.it;
    Ok(futures_util::stream::iter(params)
        .map(|p| async move {
            let items = it.browse_grid(client, MOODS_CATEGORY_ID, Some(&p)).await.ok()?;
            Some((p, items.into_iter().find_map(|i| i.thumbnail)?))
        })
        .buffer_unordered(6)
        .filter_map(|art| async move { art })
        .collect()
        .await)
}

/// The browseId every Moods & Genres tile opens with its own `params`.
const MOODS_CATEGORY_ID: &str = "FEmusic_moods_and_genres_category";

/// A card grid reached from a carousel's "More" button (e.g. an artist's full albums list).
#[tauri::command]
pub async fn get_browse_grid(
    state: St<'_>,
    id: String,
    params: Option<String>,
) -> Result<Vec<BrowseItem>, String> {
    let client = metadata_client(&state)?;
    state.it.browse_grid(client, &id, params.as_deref()).await.map_err(|e| e.to_string())
}

/// Play a playlist/album: the given items become the queue (no radio). `start` is the clicked
/// track index; `None`/omitted means "just play it" (random opener when shuffle is on).
/// `source_id` (the page's playlist/album playlist id) makes autoplay continue with that
/// context's radio when the queue runs out. `source_name` (the page title) feeds the queue
/// panel's "Next from" header; `shuffle: true` (page Shuffle buttons) turns shuffle on for
/// this queue — pass the items in their real order, the backend shuffles. `continuation` is the
/// page's next-page token when it has one: pass the tracks that are loaded and the backend walks
/// the rest into the queue in the background, so playback starts on page 1.
#[tauri::command]
pub async fn play_playlist(
    state: St<'_>,
    items: Vec<SongItem>,
    start: Option<usize>,
    source_id: Option<String>,
    source_name: Option<String>,
    shuffle: Option<bool>,
    continuation: Option<String>,
) -> Result<(), String> {
    let state = state.inner().clone();
    state
        .play_tracks(items, start, source_id, source_name, shuffle.unwrap_or(false), continuation)
        .await;
    Ok(())
}

/// Start a radio seeded on a song, artist, album or playlist (context/08). `kind` is
/// `song` | `artist` | `album` | `playlist`; `id` is the videoId (song) or browseId/playlistId
/// (everything else) — the backend resolves it to a radio playlist. `name` titles the queue.
///
/// Starting a song radio on the track that's already playing keeps it playing and replaces only
/// what comes after it; every other case replaces the queue.
#[tauri::command]
pub async fn start_radio(
    state: St<'_>,
    kind: String,
    id: String,
    name: Option<String>,
) -> Result<(), String> {
    let state = state.inner().clone();
    state.start_radio(&kind, &id, name).await
}

// --- write actions (context/01 ✎, context/15) ----------------------------------------------

fn require_login(state: &Arc<AppState>) -> Result<&innertube::YouTubeClient, String> {
    if !state.it.is_logged_in() {
        return Err("Sign in first to use this.".into());
    }
    metadata_client(state)
}

/// Like, dislike, or clear a track's rating. One command for all three: YouTube's states are
/// mutually exclusive, so a dislike un-likes in the same call and the UI never has to send two.
#[tauri::command]
pub async fn rate(state: St<'_>, video_id: String, rating: Rating) -> Result<(), String> {
    let client = require_login(&state)?;
    // Before the write, not after: a `refresh_from_next` round trip already in flight was asked
    // before this rating existed, so its answer is stale from here on either way (issue #93).
    state.rate_epoch.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
    state.it.rate(client, &video_id, rating).await.map_err(|e| e.to_string())
}

/// Add a song to the library (Library ▸ Songs), or take it out. `token` comes from the row's own
/// menu (`SongItem.library`), which is the only handle YouTube gives on this: it is a feedback
/// action, not a rating, so it leaves Liked Music alone.
#[tauri::command]
pub async fn set_song_saved(state: St<'_>, token: String) -> Result<(), String> {
    let client = require_login(&state)?;
    state.it.feedback(client, &token).await.map_err(|e| e.to_string())
}

/// Save an album to the library, or remove it. `playlist_id` is the album's `OLAK5uy_…`
/// (`AlbumPage.playlistId`).
#[tauri::command]
pub async fn set_album_saved(
    state: St<'_>,
    playlist_id: String,
    saved: bool,
) -> Result<(), String> {
    let client = require_login(&state)?;
    state.it.like_playlist(client, &playlist_id, saved).await.map_err(|e| e.to_string())
}

/// Login, plus the guard every playlist edit needs. Two ids never reach `edit_playlist`: On Repeat
/// has no YouTube playlist behind it, and Liked Music is an auto-playlist YouTube edits through the
/// rating endpoint instead. Both answer 400 there.
fn editable_playlist<'a>(
    state: &'a Arc<AppState>,
    playlist_id: &str,
) -> Result<&'a innertube::YouTubeClient, String> {
    if playlist_id == ON_REPEAT_ID {
        return Err("On Repeat builds itself from what you play.".into());
    }
    if playlist_id == LIKED_MUSIC_ID {
        return Err("Liked Music follows your likes; like the song instead.".into());
    }
    // The commands that edit one dispatch before they get here. This is the net for any that
    // doesn't, so a playlist on this machine can never reach YouTube as an id it has never seen.
    if is_local_playlist(playlist_id) {
        return Err("This playlist is on this device, so that isn't available for it.".into());
    }
    require_login(state)
}

/// Liked Music. It is indexed like the rest, because a search row is the one place YouTube tells
/// us nothing: `search` responses carry no `likeStatus` at all (live-checked 2026-08-28), so
/// membership of this list is the only way a result can draw its heart filled. Not shown in the
/// "saved in" chip, though: the thumbs-up already says it (the UI filters it out there).
const LIKED_MUSIC_ID: &str = "VLLM";
/// How long the membership index is trusted before a re-crawl. Adds and removes made in this app
/// patch it as they happen, so this window only ever covers edits made somewhere else.
const PLAYLIST_INDEX_TTL_SECS: i64 = 6 * 3600;
/// Continuation pages per playlist. YouTube hands back 100 tracks a page, so this covers 5000 of
/// them. ponytail: a hard stop, not paging state. A playlist past it marks its first 5000 tracks
/// and no more, which beats one pathological list turning a sync into hundreds of requests.
const PLAYLIST_INDEX_MAX_PAGES: usize = 50;

/// videoId → the ids of your playlists holding it, straight from SQLite with no network at all,
/// so a track list can draw the "saved" mark on its first paint. Empty until the first sync.
#[tauri::command]
pub fn playlist_index(state: St<'_>) -> std::collections::HashMap<String, Vec<String>> {
    state.db.playlist_memberships()
}

/// Rebuild that index by walking the playlists you own, then answer with it.
///
/// Nothing else knows playlist membership: the library browse gives cards, a playlist browse gives
/// one list's tracks, and InnerTube's per-video add-to-playlist dialog would be a request per row.
/// So the crawl is the price, and it is paid at most once every `PLAYLIST_INDEX_TTL_SECS`, on a
/// launch or a sign-in. Playlists you merely saved are skipped: they are someone else's, so "you
/// saved this song to it" would be a lie, and their long mixes would double the walk.
#[tauri::command]
pub async fn sync_playlist_index(
    state: St<'_>,
) -> Result<std::collections::HashMap<String, Vec<String>>, String> {
    if !state.it.is_logged_in() {
        // What is left is the playlists on this machine, which no account owns.
        state.db.clear_playlist_index();
        return Ok(state.db.playlist_memberships());
    }
    let fresh_until = state
        .db
        // `_v2`: the key changed when Liked Music joined the index, so an install with a fresh
        // stamp re-crawls once instead of showing hearts empty for another six hours.
        .get_setting("playlist_index_synced_at_v2")
        .and_then(|at| at.parse::<i64>().ok())
        .map(|at| at + PLAYLIST_INDEX_TTL_SECS);
    if fresh_until.is_some_and(|until| now_secs() < until) {
        return Ok(state.db.playlist_memberships());
    }
    let client = metadata_client(&state)?;
    let library = state.it.library_playlists(client).await.map_err(|e| e.to_string())?;
    // A degraded response that parses as an empty library would otherwise wipe every mark and
    // then call the wipe fresh for six hours. Nothing to index is nothing to trust: keep what is
    // stored and try again on the next launch.
    if library.is_empty() {
        return Ok(state.db.playlist_memberships());
    }
    let mut indexed: Vec<String> = Vec::new();
    for item in library {
        if item.id == ON_REPEAT_ID {
            continue;
        }
        // One playlist failing (a deleted id, a hiccup) must not abandon the rest of the crawl,
        // and must not drop what is already indexed for it either: leaving it out of `indexed`
        // would have `retain_playlists` forget the tracks we do know about.
        let Ok(page) = state.it.playlist(client, &item.id, None).await else {
            indexed.push(item.id);
            continue;
        };
        // A collaborative playlist reads `owned: false` (YouTube drops the editable header on it)
        // but is one you add to and remove from, so the membership index has to cover it too.
        // Liked Music is exempt: YouTube sends it without the editable header, so it reads
        // `owned: false` even though it is yours.
        if item.id != LIKED_MUSIC_ID && !page.owned && !page.collaborative {
            continue;
        }
        let mut video_ids: Vec<String> = page.items.into_iter().map(|song| song.video_id).collect();
        let mut token = page.continuation;
        for _ in 0..PLAYLIST_INDEX_MAX_PAGES {
            let Some(next) = token.take() else { break };
            let Ok(more) = state.it.playlist_continuation(client, &next).await else { break };
            video_ids.extend(more.items.into_iter().map(|song| song.video_id));
            token = more.continuation;
        }
        state.db.set_playlist_tracks(&item.id, &video_ids);
        indexed.push(item.id);
    }
    state.db.retain_playlists(&indexed);
    state.db.set_setting("playlist_index_synced_at_v2", &now_secs().to_string());
    Ok(state.db.playlist_memberships())
}

/// `false` means the playlist already had the track and YouTube added nothing — not an error, but
/// the UI must not draw an optimistic row for it (there is no real row to remove later).
/// With `allow_duplicates` set to `true`, `true` is returned for a duplicate that was added on purpose.
#[tauri::command]
pub async fn add_to_playlist(
    state: St<'_>,
    playlist_id: String,
    video_id: String,
    allow_duplicates: Option<bool>,
) -> Result<bool, String> {
    let client = editable_playlist(&state, &playlist_id)?;
    let added = state
        .it
        .playlist_add(client, &playlist_id, &video_id, allow_duplicates.unwrap_or(false))
        .await
        .map_err(|e| e.to_string())?;
    // Also on `false`: YouTube refusing a duplicate means the playlist holds the track, which is
    // exactly what the index should say. A stale index is how it got asked in the first place.
    state.db.add_playlist_track(&playlist_id, &video_id);
    Ok(added)
}

#[tauri::command]
pub async fn remove_from_playlist(
    state: St<'_>,
    playlist_id: String,
    video_id: String,
    set_video_id: String,
) -> Result<(), String> {
    if is_local_playlist(&playlist_id) {
        let row = set_video_id.parse().map_err(|_| GONE.to_string())?;
        return remove_local_rows(&state, &playlist_id, &[row]);
    }
    let client = editable_playlist(&state, &playlist_id)?;
    state
        .it
        .playlist_remove(client, &playlist_id, &video_id, &set_video_id)
        .await
        .map_err(|e| e.to_string())?;
    state.db.remove_playlist_track(&playlist_id, &video_id);
    Ok(())
}

/// Remove several tracks from one playlist in a single request (the bulk bar's Remove).
///
/// All or nothing: YouTube applies the whole action list or rejects it, so the UI can revert its
/// optimistic removal on an error without working out which rows made it.
#[tauri::command]
pub async fn remove_many_from_playlist(
    state: St<'_>,
    playlist_id: String,
    tracks: Vec<(String, String)>,
) -> Result<(), String> {
    if is_local_playlist(&playlist_id) {
        let rows = tracks
            .iter()
            .map(|(_, row)| row.parse().map_err(|_| GONE.to_string()))
            .collect::<Result<Vec<i64>, _>>()?;
        return remove_local_rows(&state, &playlist_id, &rows);
    }
    let client = editable_playlist(&state, &playlist_id)?;
    state
        .it
        .playlist_remove_many(client, &playlist_id, &tracks)
        .await
        .map_err(|e| e.to_string())?;
    for (video_id, _) in &tracks {
        state.db.remove_playlist_track(&playlist_id, video_id);
    }
    Ok(())
}

/// Move a track within a playlist. `before_set_video_id` None = move to the end;
/// local playlists use row ids, while YouTube ones use `setVideoId`.
#[tauri::command]
pub async fn move_in_playlist(
    state: St<'_>,
    playlist_id: String,
    set_video_id: String,
    before_set_video_id: Option<String>,
) -> Result<(), String> {
    if is_local_playlist(&playlist_id) {
        let row = set_video_id.parse().map_err(|_| GONE.to_string())?;
        let before = match before_set_video_id {
            Some(b) => Some(b.parse().map_err(|_| GONE.to_string())?),
            None => None,
        };
        let key = local_key(&playlist_id)?;
        return state
            .db
            .move_local_playlist_track(key, row, before, crate::db::now_secs())
            .map_err(db_err);
    }
    let client = editable_playlist(&state, &playlist_id)?;
    state
        .it
        .playlist_move(client, &playlist_id, &set_video_id, before_set_video_id.as_deref())
        .await
        .map_err(|e| e.to_string())?;
    Ok(())
}

/// `local`: keep it on this machine instead of the account (issue #251), which is the only kind
/// there is while signed out. Answers the new playlist's id, a `LOCALPLAYLIST:` browseId for that.
#[tauri::command]
pub async fn create_playlist(
    state: St<'_>,
    title: String,
    local: Option<bool>,
) -> Result<String, String> {
    if local.unwrap_or(false) {
        let title = title.trim();
        if title.is_empty() {
            return Err("Give the playlist a name.".into());
        }
        let id = state.db.create_local_playlist(title, crate::db::now_secs()).map_err(db_err)?;
        return Ok(format!("{LOCAL_PLAYLIST_PREFIX}{id}"));
    }
    let client = require_login(&state)?;
    state.it.create_playlist(client, &title).await.map_err(|e| e.to_string())
}

/// Edit a playlist you own, from the "Edit playlist" dialog: name, description, visibility.
///
/// Each field is `None` when the user left it alone, and only what changed is sent: an edit of
/// the name must not blank a description we failed to read back off the page.
#[tauri::command]
pub async fn edit_playlist_details(
    state: St<'_>,
    playlist_id: String,
    name: Option<String>,
    description: Option<String>,
    public: Option<bool>,
) -> Result<(), String> {
    // Nobody else can see a playlist on this machine, so there is no visibility to set.
    if is_local_playlist(&playlist_id) {
        let name = name.as_deref().map(str::trim);
        if name == Some("") {
            return Err("Give the playlist a name.".into());
        }
        let key = local_key(&playlist_id)?;
        return state
            .db
            .edit_local_playlist(key, name, description.as_deref(), crate::db::now_secs())
            .map_err(db_err);
    }
    let client = editable_playlist(&state, &playlist_id)?;
    // The switch is two-state; YouTube's third value (UNLISTED) is only ever left as it was.
    let privacy = public.map(|p| if p { "PUBLIC" } else { "PRIVATE" });
    state
        .it
        .playlist_edit_details(
            client,
            &playlist_id,
            name.as_deref(),
            description.as_deref(),
            privacy,
        )
        .await
        .map_err(|e| e.to_string())
}

/// Custom playlist artwork, in both places it lives.
///
/// Setting one is local-first: the picked image is copied in beside the local-music covers and
/// answered straight back, then pushed to YouTube Music in the background (`sync_cover`), because
/// the upload is three round trips and nobody should watch a spinner for their own file.
///
/// Dropping one waits, and that is deliberate. Once a cover has been up there, YouTube's own
/// thumbnail *is* that cover, so a local-first removal would fall back to the very image being
/// removed and only reach the rebuilt collage a beat later: two swaps, the first of them pointless.
/// The clear is a single small call, so it answers with the thumbnail YouTube rebuilt and the UI
/// changes once.
#[tauri::command]
pub async fn set_playlist_cover(
    app: tauri::AppHandle,
    state: St<'_>,
    playlist_id: String,
    path: Option<String>,
) -> Result<CoverResult, String> {
    let key = cover_key(&playlist_id);
    let stored = state.db.get_setting(&key);
    let Some(src) = path else {
        // YouTube first, so the local copy is still on screen while it answers. Its refusal is
        // never fatal though: dropping the cover from this machine is what the user clicked, and
        // an account that was not allowed to set one up there has nothing to clear anyway.
        let thumbnail = match clear_cover_on_youtube(&state, &playlist_id).await {
            Ok(t) => {
                state.db.delete_setting(&synced_key(&playlist_id));
                t
            }
            Err(e) => {
                tracing::warn!(playlist_id, error = %e, "custom cover not cleared on YouTube Music");
                // Only worth saying when a cover of ours actually reached the account: otherwise
                // there was nothing up there to keep, and the warning would be a lie.
                if state.db.get_setting(&synced_key(&playlist_id)).is_some() {
                    let _ = state.app.emit(
                        "cover-error",
                        serde_json::json!({
                            "message": "Removed here, but YouTube Music kept its copy.",
                        }),
                    );
                }
                None
            }
        };
        state.db.delete_setting(&key);
        if let Some(old) = stored {
            let _ = std::fs::remove_file(old);
        }
        return Ok(CoverResult { cover: None, thumbnail });
    };
    store_cover(&app, &state, &playlist_id, std::path::Path::new(&src))
}

/// Copy an image in as a playlist's artwork, answer the local copy, and send it on to YouTube
/// Music in the background. The picker's half of [`set_playlist_cover`], and how a Spotify import
/// carries the playlist's own cover over (#375).
pub(crate) fn store_cover(
    app: &tauri::AppHandle,
    state: &Arc<AppState>,
    playlist_id: &str,
    src: &std::path::Path,
) -> Result<CoverResult, String> {
    use tauri::Manager;
    // What YouTube's uploader will take. WebP is not on the list: it answers 415 for one, and a
    // cover that only works on this machine is worse than one the picker never offered.
    const IMAGE_EXTS: [&str; 3] = ["jpg", "jpeg", "png"];

    let key = cover_key(playlist_id);
    let stored = state.db.get_setting(&key);
    let ext = src.extension().and_then(|e| e.to_str()).unwrap_or_default().to_ascii_lowercase();
    if !IMAGE_EXTS.contains(&ext.as_str()) {
        return Err("Pick a JPEG or PNG image: YouTube Music won't take anything else.".into());
    }
    // ponytail: a flat size cap instead of downscaling. It keeps a 40px sidebar thumb from
    // decoding a camera raw in the webview and the upload from swallowing one; reach for the
    // `image` crate and a real resize only if 8 MB turns out to bother anyone.
    const MAX_BYTES: u64 = 8 * 1024 * 1024;
    if src.metadata().map(|m| m.len()).unwrap_or(0) > MAX_BYTES {
        return Err("That image is over 8 MB. Pick a smaller one.".into());
    }
    let dir = crate::local::covers_dir(app).join("playlists");
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    // Timestamped, so replacing a cover can't be served out of the webview's cache under the name
    // it already has. The id is filtered to filename characters rather than trusted: it arrives
    // from the UI, and a `..` in it would write outside this directory.
    let stem: String = playlist_id
        .chars()
        .filter(|c| c.is_ascii_alphanumeric() || *c == '-' || *c == '_')
        .collect();
    let dest = dir.join(format!("{stem}-{}.{ext}", crate::db::now_secs()));
    std::fs::copy(src, &dest).map_err(|e| e.to_string())?;
    // Only now is the cover it replaces safe to unlink. Dropping it any earlier means a picked
    // file this command goes on to refuse (wrong format, too big, unreadable) takes the artwork
    // already on screen down with it, and the toast talks about the new file while the old one is
    // the thing that just disappeared.
    if let Some(old) = stored {
        let _ = std::fs::remove_file(old);
    }
    let dest = dest.to_string_lossy().to_string();
    // The covers directory is allowed recursively at startup, but the first cover on a fresh
    // install is written after that ran, so name this file explicitly too.
    let _ = app.asset_protocol_scope().allow_file(&dest);
    state.db.set_setting(&key, &dest);
    sync_cover(state, playlist_id, dest.clone());
    Ok(CoverResult { cover: Some(dest), thumbnail: None })
}

/// What the UI needs to draw after a cover changed: where the local copy is, and (on a removal)
/// the thumbnail YouTube rebuilt in its place.
#[derive(serde::Serialize)]
pub struct CoverResult {
    cover: Option<String>,
    thumbnail: Option<String>,
}

/// Send the cover on to YouTube Music behind the picker's back: the local copy is already on
/// screen, and the upload is a three-call round trip nobody should wait through.
///
/// A failure is a toast, not a rollback: the artwork is still right here, and it is still this
/// playlist's cover on this machine. Signed out (or On Repeat, which YouTube has never heard of),
/// there is nothing to sync and local is all there ever was.
fn sync_cover(state: &Arc<AppState>, playlist_id: &str, path: String) {
    if playlist_id == ON_REPEAT_ID || is_local_playlist(playlist_id) || !state.it.is_logged_in() {
        return;
    }
    let state = Arc::clone(state);
    let playlist_id = playlist_id.to_owned();
    tauri::async_runtime::spawn(async move {
        let Some(client) = state.clients.get(innertube::METADATA_CLIENT) else {
            return;
        };
        // Read here, not on the command's thread: the file was just written and the caller has its
        // answer already.
        let result = match std::fs::read(&path) {
            Ok(image) => state.it.playlist_set_cover(client, &playlist_id, image).await,
            Err(e) => Err(innertube::Error::Other(e.to_string())),
        };
        match result {
            // Remembered so a later removal knows whether YouTube has anything of ours to drop.
            Ok(()) => state.db.set_setting(&synced_key(&playlist_id), "1"),
            Err(e) => {
                tracing::warn!(playlist_id, error = %e, "playlist cover didn't reach YouTube Music");
                let message = match e {
                    // The one refusal with a known cause and no fix inside this app. Say it once,
                    // plainly, and leave the cover where it already is: on this machine.
                    innertube::Error::CoverRefused => format!("Artwork saved on this device. {e}"),
                    e => format!("Artwork saved here, but the upload to YouTube Music failed: {e}"),
                };
                let _ = state.app.emit("cover-error", serde_json::json!({ "message": message }));
            }
        }
    });
}

/// Drop the custom thumbnail from the account, answering the one YouTube rebuilt from the tracks.
/// Nothing to do (and nothing to answer with) when there is no account behind the playlist.
async fn clear_cover_on_youtube(
    state: &Arc<AppState>,
    playlist_id: &str,
) -> Result<Option<String>, String> {
    if playlist_id == ON_REPEAT_ID || is_local_playlist(playlist_id) || !state.it.is_logged_in() {
        return Ok(None);
    }
    let client = metadata_client(state)?;
    state.it.playlist_clear_cover(client, playlist_id).await.map_err(|e| e.to_string())
}

fn cover_key(playlist_id: &str) -> String {
    // Browse ids arrive `VL`-prefixed and playlist ids don't; one playlist, one key either way.
    format!("playlist_cover:{}", playlist_id.strip_prefix("VL").unwrap_or(playlist_id))
}

/// Set once a cover of ours has actually landed on the account, so a removal knows whether there
/// is anything up there to warn about failing to clear.
fn synced_key(playlist_id: &str) -> String {
    format!("{}:synced", cover_key(playlist_id))
}

/// The custom artwork stored for a playlist, if the file is still there. The user owns that
/// directory and can empty it, and a dead path renders as a broken image.
fn custom_cover(state: &Arc<AppState>, playlist_id: &str) -> Option<String> {
    let path = state.db.get_setting(&cover_key(playlist_id))?;
    std::path::Path::new(&path).is_file().then_some(path)
}

#[tauri::command]
pub async fn delete_playlist(state: St<'_>, playlist_id: String) -> Result<(), String> {
    if is_local_playlist(&playlist_id) {
        state.db.delete_local_playlist(local_key(&playlist_id)?).map_err(db_err)?;
        // Its artwork was a copy made for it, so it goes too.
        if let Some(cover) = state.db.get_setting(&cover_key(&playlist_id)) {
            let _ = std::fs::remove_file(cover);
            state.db.delete_setting(&cover_key(&playlist_id));
        }
        return Ok(());
    }
    let client = editable_playlist(&state, &playlist_id)?;
    state.it.delete_playlist(client, &playlist_id).await.map_err(|e| e.to_string())?;
    state.db.forget_playlist(&playlist_id);
    Ok(())
}

// --- playlists on this machine (issue #251) --------------------------------------------------
// A `LOCALPLAYLIST:<n>` id reaches the same commands a YouTube playlist does (get, add, remove,
// edit, cover, delete), and each one answers it from SQLite before any of the YouTube path runs.
// That is what lets every playlist surface in the UI take both kinds without branching.

const GONE: &str = "This playlist is no longer on this device.";

/// `LOCALPLAYLIST:<n>` → n. An id with the prefix and no number is still not YouTube's, so it is
/// an error rather than a fall-through to a browse YouTube would 400.
fn local_key(id: &str) -> Result<i64, String> {
    id.strip_prefix(LOCAL_PLAYLIST_PREFIX).and_then(|n| n.parse().ok()).ok_or_else(|| GONE.into())
}

fn db_err(e: rusqlite::Error) -> String {
    match e {
        rusqlite::Error::QueryReturnedNoRows => GONE.into(),
        e => e.to_string(),
    }
}

/// The library card. The subtitle is English on purpose: Rust never learns the UI language, so
/// `api.ts` rewords it on the way in, the same as On Repeat's.
fn local_playlist_card(state: &Arc<AppState>, p: &crate::db::LocalPlaylist) -> BrowseItem {
    let id = format!("{LOCAL_PLAYLIST_PREFIX}{}", p.id);
    // A cover the user picked, else the first track's art, which is what YouTube shows for a
    // playlist too short for its four-track collage.
    let thumbnail = custom_cover(state, &id).or_else(|| {
        let first = p.first_song.as_deref()?;
        serde_json::from_str::<SongItem>(first).ok()?.thumbnail
    });
    BrowseItem {
        kind: "playlist",
        id,
        title: p.title.clone(),
        subtitle: Some(format!("{} songs", p.count)),
        thumbnail,
        duration: None,
        album_id: None,
        artist_runs: Vec::new(),
        play_count: None,
        is_video: false,
        is_upload: false,
        explicit: false,
    }
}

fn local_playlist_page(state: &Arc<AppState>, id: &str) -> Result<PlaylistPage, String> {
    let key = local_key(id)?;
    let p = state.db.local_playlist(key).ok_or(GONE)?;
    // The row id rides as the `set_video_id`, the handle every removal path already sends back.
    // A row whose JSON no longer parses (a `SongItem` shape change) is skipped, not fatal.
    let items: Vec<SongItem> = state
        .db
        .local_playlist_tracks(key)
        .into_iter()
        .filter_map(|(row, json, added_at)| {
            let song: SongItem = serde_json::from_str(&json).ok()?;
            Some(SongItem { set_video_id: Some(row.to_string()), added_at: Some(added_at), ..song })
        })
        .collect();
    Ok(PlaylistPage {
        title: Some(p.title),
        subtitle: Some(format!("{} songs", items.len())), // the page words its own count
        thumbnail: items.first().and_then(|s| s.thumbnail.clone()),
        description: (!p.description.is_empty()).then_some(p.description),
        privacy: None,
        cover: custom_cover(state, id),
        items,
        continuation: None, // it is all here: nothing to page through
        owned: true,
        collaborative: false,
        sort_menu: None, // no server to keep an order, so every sort is done on the page
        suggestions: None, // YouTube suggests only for its own playlists
    })
}

/// What a track keeps once it is in a playlist: the song, none of the context it was added from
/// (`shed_queue_context`), and no snapshot of account state that would go stale behind it. The
/// rating is read live (the override map, the saved-in index), and Library ▸ Songs tokens are
/// minted per row for one account while these playlists belong to none.
pub(crate) fn playlist_row(s: SongItem) -> SongItem {
    SongItem { rating: None, library: None, ..shed_queue_context(s) }
}

fn remove_local_rows(state: &Arc<AppState>, playlist_id: &str, rows: &[i64]) -> Result<(), String> {
    let key = local_key(playlist_id)?;
    state.db.remove_local_playlist_tracks(key, rows, crate::db::now_secs()).map_err(db_err)
}

/// Just the playlists on this machine, as library cards. The UI re-reads these after every edit
/// (the count and the artwork follow the tracks), and falls back on them when the account's
/// library can't be fetched, since these need no network.
#[tauri::command]
pub async fn local_playlists(state: St<'_>) -> Result<Vec<BrowseItem>, String> {
    Ok(state.db.local_playlists().iter().map(|p| local_playlist_card(&state, p)).collect())
}

/// Add tracks to a playlist on this machine, answering per track whether it went in (`false`: it
/// was there already, refused the way YouTube refuses one). Whole `SongItem`s rather than the
/// videoIds `add_to_playlist` takes, because nothing will ever fill in a title or artwork later:
/// there is no YouTube playlist to re-read. Files on disk are welcome, unlike in a YouTube one.
#[tauri::command]
pub async fn add_to_local_playlist(
    state: St<'_>,
    playlist_id: String,
    items: Vec<SongItem>,
) -> Result<Vec<bool>, String> {
    let key = local_key(&playlist_id)?;
    let rows = items
        .into_iter()
        .map(|song| {
            let song = playlist_row(song);
            let json = serde_json::to_string(&song).map_err(|e| e.to_string())?;
            Ok((song.video_id, json))
        })
        .collect::<Result<Vec<_>, String>>()?;
    state.db.add_local_playlist_tracks(key, &rows, crate::db::now_secs()).map_err(db_err)
}

#[tauri::command]
pub async fn subscribe(state: St<'_>, channel_id: String, subscribed: bool) -> Result<(), String> {
    let client = require_login(&state)?;
    state.it.subscribe(client, &channel_id, subscribed).await.map_err(|e| e.to_string())
}

// --- blocked artists (blocked.rs, plan 046) ----------------------------------------------------

/// The blocked-artist list, for the settings pane.
#[tauri::command]
pub async fn get_blocked_artists(state: St<'_>) -> Result<Vec<BlockedArtist>, String> {
    Ok(crate::blocked::list(&state.db))
}

/// Block an artist: persist, re-arm the fetch filter, and drop them out of the live queue. Returns
/// the new list. `id` is the channel browseId when the caller has one (a track row often does not).
#[tauri::command]
pub async fn block_artist(
    state: St<'_>,
    id: Option<String>,
    name: String,
) -> Result<Vec<BlockedArtist>, String> {
    let name = name.trim().to_string();
    if name.is_empty() {
        return Err("an artist needs a name to be blocked".into());
    }
    let state = state.inner().clone();
    let list =
        crate::blocked::block(&state.db, BlockedArtist { id: id.filter(|i| !i.is_empty()), name });
    let predicate = crate::blocked::block_list(&state.db);
    state.it.set_blocked(predicate.clone());
    // The fetch filter only covers what is fetched from here on, so the queue already on screen
    // has to be cleaned out separately or the block reads as having done nothing.
    state.purge_blocked(&predicate).await;
    Ok(list)
}

#[tauri::command]
pub async fn unblock_artist(state: St<'_>, key: String) -> Result<Vec<BlockedArtist>, String> {
    let list = crate::blocked::unblock(&state.db, &key);
    state.it.set_blocked(crate::blocked::block_list(&state.db));
    Ok(list)
}

// --- Spotify import (spotify.rs, import.rs, #375) ----------------------------------------------
//
// Errors from these are short codes (`private`, `busy`, `rate_limited`, ...) that the UI words in
// the user's language; anything else is a network error passed through as text.

/// Read a pasted Spotify link, or a file picked from disk (the data export zip, one of its JSON
/// files, or a CSV). Answers what it holds; the tracks stay here until `import_start`.
#[tauri::command]
pub async fn import_read(
    link: Option<String>,
    path: Option<String>,
) -> Result<crate::import::Preview, String> {
    if let Some(link) = link {
        return crate::import::read_link(&link).await;
    }
    let path = path.ok_or("nothing_read")?;
    let bytes = std::fs::read(&path).map_err(|e| e.to_string())?;
    crate::import::read_file(&bytes, &path)
}

/// A file dropped on the window. A webview drop has the bytes but no path, so they come over as
/// the raw request body, with the name in `x-file-name` (percent-encoded: headers are ASCII).
#[tauri::command]
pub async fn import_read_file(
    request: tauri::ipc::Request<'_>,
) -> Result<crate::import::Preview, String> {
    let tauri::ipc::InvokeBody::Raw(bytes) = request.body() else {
        return Err("unreadable".into());
    };
    let name = request
        .headers()
        .get("x-file-name")
        .and_then(|v| v.to_str().ok())
        .and_then(|v| urlencoding::decode(v).ok())
        .map(|v| v.into_owned())
        .unwrap_or_default();
    crate::import::read_file(bytes, &name)
}

/// Start matching the lists picked out of the last read (their indices in its preview).
#[tauri::command]
pub async fn import_start(
    state: St<'_>,
    lists: Vec<usize>,
) -> Result<crate::import::Snapshot, String> {
    crate::import::start(&state, lists)
}

#[tauri::command]
pub async fn import_status() -> Result<Option<crate::import::Snapshot>, String> {
    Ok(crate::import::status())
}

/// The rows of one tier, for the review step.
#[tauri::command]
pub async fn import_rows(
    tier: crate::import::Tier,
) -> Result<Vec<crate::import::ReviewRow>, String> {
    Ok(crate::import::rows(tier))
}

/// The user's pick for one row; `None` leaves the track out.
#[tauri::command]
pub async fn import_pick(
    state: St<'_>,
    key: String,
    song: Option<SongItem>,
) -> Result<crate::import::Snapshot, String> {
    crate::import::pick(&state, &key, song)
}

#[tauri::command]
pub async fn import_create(
    state: St<'_>,
    options: crate::import::CreateOptions,
) -> Result<(), String> {
    crate::import::create(&state, options)
}

/// Stop a running import, or put away a finished one.
#[tauri::command]
pub async fn import_cancel(state: St<'_>) -> Result<(), String> {
    crate::import::cancel(&state);
    Ok(())
}

/// The Spotify link a playlist was imported from, when it was imported from one.
#[tauri::command]
pub async fn import_source(state: St<'_>, playlist_id: String) -> Result<Option<String>, String> {
    Ok(crate::import::source_url(&state, &playlist_id))
}

/// "Update from Spotify": re-read the playlist's link and apply what changed.
#[tauri::command]
pub async fn import_update(
    state: St<'_>,
    playlist_id: String,
) -> Result<crate::import::Snapshot, String> {
    crate::import::update(&state, playlist_id).await
}

/// What a Spotify track, album or artist link is on YouTube Music.
#[tauri::command]
pub async fn import_resolve(
    state: St<'_>,
    link: String,
) -> Result<crate::import::Resolved, String> {
    crate::import::resolve(&state, &link).await
}

// --- local music (local.rs) ------------------------------------------------------------------

/// Rescan the watched folders and return the library. The scan is the deletion check too: its
/// `removed` list is every id that was on screen but is gone from disk, so the UI can drop those
/// tiles without waiting for anyone to click a dead one.
#[tauri::command]
pub async fn get_local_library(state: St<'_>) -> Result<crate::local::LocalLibrary, String> {
    scan_local(&state).await
}

#[tauri::command]
pub async fn add_local_folder(
    state: St<'_>,
    path: String,
) -> Result<crate::local::LocalLibrary, String> {
    crate::local::add_folder(&state.db, path);
    scan_local(&state).await
}

/// Stop watching a folder. Its tracks disappear from the library on the rescan that follows (they
/// come back untouched if the folder is added again — nothing on disk is modified).
#[tauri::command]
pub async fn remove_local_folder(
    state: St<'_>,
    path: String,
) -> Result<crate::local::LocalLibrary, String> {
    crate::local::remove_folder(&state.db, &path);
    scan_local(&state).await
}

/// Disk IO + tag parsing off the async runtime's worker threads.
async fn scan_local(state: &Arc<AppState>) -> Result<crate::local::LocalLibrary, String> {
    let app = state.app.clone();
    let state = state.clone();
    let covers = crate::local::covers_dir(&state.app);
    let lib = tauri::async_runtime::spawn_blocking(move || crate::local::scan(&state.db, &covers))
        .await
        .map_err(|e| e.to_string())?;
    // Artwork reaches the page over the asset protocol, which starts out allowing nothing.
    crate::local::allow_covers(&app, &lib.songs);
    Ok(lib)
}

// --- Listen Together (context/19) ----------------------------------------------------------

/// Current client-side LT state (status, role, room, participants, pending joins, suggestions).
#[tauri::command]
pub async fn lt_get_state(state: St<'_>) -> Result<serde_json::Value, String> {
    Ok(state.lt.snapshot().await)
}

/// Set + persist the sync server URL (e.g. the Tailscale Funnel `wss://…` address).
#[tauri::command]
pub async fn lt_set_server_url(state: St<'_>, url: String) -> Result<(), String> {
    let url = url.trim().to_string();
    state.db.set_setting("lt_server_url", &url);
    state.lt.set_server_url(url).await;
    Ok(())
}

#[tauri::command]
pub async fn lt_create_room(state: St<'_>, username: String) -> Result<(), String> {
    state.lt.create_room(username).await;
    Ok(())
}

#[tauri::command]
pub async fn lt_join_room(state: St<'_>, code: String, username: String) -> Result<(), String> {
    state.lt.join_room(code, username).await;
    Ok(())
}

#[tauri::command]
pub async fn lt_leave(state: St<'_>) -> Result<(), String> {
    state.lt.leave().await;
    Ok(())
}

#[tauri::command]
pub async fn lt_approve_join(state: St<'_>, user_id: String) -> Result<(), String> {
    state.lt.approve_join(user_id).await;
    Ok(())
}

#[tauri::command]
pub async fn lt_reject_join(state: St<'_>, user_id: String) -> Result<(), String> {
    state.lt.reject_join(user_id).await;
    Ok(())
}

#[tauri::command]
pub async fn lt_kick(state: St<'_>, user_id: String) -> Result<(), String> {
    state.lt.kick(user_id).await;
    Ok(())
}

#[tauri::command]
pub async fn lt_transfer_host(state: St<'_>, user_id: String) -> Result<(), String> {
    state.lt.transfer_host(user_id).await;
    Ok(())
}

/// Guest: send a track to the session queue (auto-approved by the host client, which stamps
/// who added it).
#[tauri::command]
pub async fn lt_suggest(state: St<'_>, item: SongItem) -> Result<(), String> {
    state.lt.suggest(crate::state::song_to_track(&item)).await;
    Ok(())
}

/// Host: approve a suggestion — add it to the real queue and notify the suggester. (Unused since
/// guest adds auto-approve, kept for a future "require approval" setting.)
#[tauri::command]
pub async fn lt_approve_suggestion(state: St<'_>, id: String) -> Result<(), String> {
    if let Some(track) = state.lt.approve_suggestion(id).await {
        state.inner().clone().lt_enqueue_track(track).await;
    }
    Ok(())
}

#[tauri::command]
pub async fn lt_reject_suggestion(state: St<'_>, id: String) -> Result<(), String> {
    state.lt.reject_suggestion(id).await;
    Ok(())
}

/// Guest: force a re-sync with the room (drift correction).
#[tauri::command]
pub async fn lt_request_sync(state: St<'_>) -> Result<(), String> {
    state.lt.request_sync().await;
    Ok(())
}

// --- lyrics ---------------------------------------------------------------------------------

/// Lyrics for a track (cached). The UI passes the metadata it already has from `now-playing`;
/// `duration` is mpv's length in seconds. `None` = no lyrics found anywhere. `source` asks one
/// provider alone, uncached: the source picker's preview.
#[tauri::command]
pub async fn get_lyrics(
    state: St<'_>,
    video_id: String,
    title: String,
    artists: String,
    album: Option<String>,
    duration: Option<f64>,
    source: Option<String>,
) -> Result<Option<crate::lyrics::Lyrics>, String> {
    let req = crate::lyrics::LyricsRequest { video_id, title, artists, album, duration };
    crate::lyrics::get_lyrics(state.inner(), req, source).await
}

/// Keep one provider's lyrics for this song (`source`), or hand it back to the provider order
/// (`None`). Returns what the song shows now.
#[tauri::command]
pub async fn choose_lyrics_source(
    state: St<'_>,
    video_id: String,
    title: String,
    artists: String,
    album: Option<String>,
    duration: Option<f64>,
    source: Option<String>,
) -> Result<Option<crate::lyrics::Lyrics>, String> {
    let req = crate::lyrics::LyricsRequest { video_id, title, artists, album, duration };
    Ok(crate::lyrics::choose_source(state.inner(), req, source).await)
}

#[tauri::command]
pub fn set_lyrics_offset(state: St<'_>, video_id: String, offset_ms: i64) {
    crate::lyrics::set_offset(state.inner(), &video_id, offset_ms);
}

/// Every lyrics provider in the user's order, for Settings and the source picker.
#[tauri::command]
pub fn lyrics_providers(state: St<'_>) -> Vec<crate::lyrics::ProviderInfo> {
    crate::lyrics::providers(state.inner())
}

// --- Changelog ------------------------------------------------------------------------------

#[derive(Clone, serde::Serialize)]
pub struct ReleaseNote {
    version: String,
    /// `YYYY-MM-DD`, or empty for an unpublished tag.
    date: String,
    /// The release description, verbatim markdown. The About tab renders it.
    body: String,
}

/// What's new, read straight from the GitHub releases API so the release description is the only
/// place the changelog is written. Cached for the process: the list only changes when a release
/// is cut, and unauthenticated GitHub allows 60 requests an hour.
#[tauri::command]
pub async fn release_notes() -> Result<Vec<ReleaseNote>, String> {
    static CACHE: std::sync::OnceLock<Vec<ReleaseNote>> = std::sync::OnceLock::new();
    if let Some(cached) = CACHE.get() {
        return Ok(cached.clone());
    }
    #[derive(serde::Deserialize)]
    struct GhRelease {
        tag_name: String,
        published_at: Option<String>,
        body: Option<String>,
        draft: bool,
        prerelease: bool,
    }
    let releases: Vec<GhRelease> = crate::http::client()
        .get("https://api.github.com/repos/SimoHypers/limusic/releases?per_page=20")
        .header("User-Agent", concat!("Limusic/", env!("CARGO_PKG_VERSION")))
        .header("Accept", "application/vnd.github+json")
        .timeout(std::time::Duration::from_secs(15))
        .send()
        .await
        .map_err(|e| e.to_string())?
        .error_for_status()
        .map_err(|e| e.to_string())?
        .json()
        .await
        .map_err(|e| e.to_string())?;
    let notes: Vec<ReleaseNote> = releases
        .into_iter()
        .filter(|r| !r.draft && !r.prerelease)
        .map(|r| ReleaseNote {
            version: r.tag_name.trim_start_matches('v').to_string(),
            date: r
                .published_at
                .and_then(|d| d.split('T').next().map(str::to_string))
                .unwrap_or_default(),
            body: r.body.unwrap_or_default(),
        })
        .collect();
    Ok(CACHE.get_or_init(|| notes).clone())
}

/// Whether this build can install an update itself, or only point the user at the download.
///
/// Tauri's Linux updater knows one trick: rewrite an AppImage in place. It takes the path from
/// `Env::appimage` and, when that is unset, falls back to `current_exe()` and writes the downloaded
/// AppImage bytes over whatever it finds there. On the `.rpm` and on distro packages (the AUR's
/// `limusic-bin`) that is a package-manager-owned `/usr/bin/limusic-app`: it fails on permissions
/// rather than doing damage, but offering the button at all is a lie. Those users update through
/// their package manager, so the UI shows them a download link instead.
///
/// Reads the same `Env::appimage` the updater plugin decides on, so the two cannot disagree.
#[tauri::command]
pub fn can_self_update(app: tauri::AppHandle) -> bool {
    #[cfg(target_os = "linux")]
    {
        use tauri::Manager;
        app.env().appimage.is_some()
    }
    // Windows runs the NSIS installer and macOS swaps the .app bundle; both work however the app
    // was installed.
    #[cfg(not(target_os = "linux"))]
    {
        let _ = app;
        true
    }
}

/// The beta channel's manifest. `beta` is a permanent prerelease holding nothing but this file, and
/// the release workflows move it to the newest release candidate, or to the newest release once that
/// is ahead, so the URL never changes.
const BETA_MANIFEST: &str =
    "https://github.com/SimoHypers/limusic/releases/download/beta/latest.json";

/// What the updater plugin's own `check` command returns, so the UI can wrap it in the plugin's
/// `Update` class and install it the usual way.
#[derive(serde::Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BetaUpdate {
    rid: tauri::ResourceId,
    current_version: String,
    version: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    body: Option<String>,
    raw_json: serde_json::Value,
}

/// The updater plugin's `check()`, pointed at the beta manifest. The plugin takes its endpoint from
/// tauri.conf.json and its JS `check` has no way to pass another, so this mirrors its `check`
/// command (tauri-plugin-updater 2.10.1, `commands.rs`) with the endpoint swapped. The `Update` goes
/// into the same resource table, which is what lets the plugin's `downloadAndInstall` find it.
///
/// Any different version counts, same as `allowDowngrades` on stable: the pointer only moves forward
/// by itself, so a lower version there is a beta rollback somebody made on purpose.
#[tauri::command]
pub async fn check_beta_update(webview: tauri::Webview) -> Result<Option<BetaUpdate>, String> {
    use tauri::Manager;
    use tauri_plugin_updater::UpdaterExt;
    let url = tauri::Url::parse(BETA_MANIFEST).map_err(|e| e.to_string())?;
    let update = webview
        .updater_builder()
        .endpoints(vec![url])
        .map_err(|e| e.to_string())?
        .version_comparator(|current, remote| remote.version != current)
        .build()
        .map_err(|e| e.to_string())?
        .check()
        .await
        .map_err(|e| e.to_string())?;
    Ok(update.map(|u| BetaUpdate {
        current_version: u.current_version.clone(),
        version: u.version.clone(),
        body: u.body.clone(),
        raw_json: u.raw_json.clone(),
        rid: webview.resources_table().add(u),
    }))
}

/// Open a link from the UI in the real browser. An `<a href>` inside the webview would navigate
/// the app itself off the SPA, with no way back.
#[tauri::command]
pub async fn open_external(url: String) -> Result<(), String> {
    crate::lastfm::open_browser(&url)
}

/// Real quit from the UI (Ctrl+Q / Cmd+Q). Positions are saved by the Exit handler in lib.rs.
#[tauri::command]
pub fn quit_app(app: tauri::AppHandle) {
    app.exit(0);
}

// --- Diagnostics ----------------------------------------------------------------------------

/// The bug-report blob for Settings ▸ About: environment header plus the redacted tail of
/// `limusic.log`. See `crate::diagnostics`.
#[tauri::command]
pub fn diagnostics(app: tauri::AppHandle, state: St<'_>) -> String {
    crate::diagnostics::report(&app, &state.db)
}

/// The environment block on its own, for prefilling the bug form's `system` field. GitHub's query
/// parameters only reach `input` and `textarea` fields, so this is how the app tells us what it is
/// running on without the user typing it.
#[tauri::command]
pub fn diagnostics_summary(app: tauri::AppHandle, state: St<'_>) -> String {
    crate::diagnostics::summary(&app, &state.db)
}

/// The same text written to a path the user picked in a save dialog, for attaching to an issue
/// when it is too long to paste comfortably.
#[tauri::command]
pub fn save_diagnostics(app: tauri::AppHandle, state: St<'_>, path: String) -> Result<(), String> {
    std::fs::write(&path, crate::diagnostics::report(&app, &state.db)).map_err(|e| e.to_string())
}

/// The webview's own errors, into the same log file as everything else. Without this a blank
/// screen or a rejected `invoke` leaves no trace at all in the log a user hands over.
#[tauri::command]
pub fn log_ui(level: String, message: String) {
    // Bounded: a throwing `$effect` re-fires every frame, and the file has no size cap.
    let message: String = message.chars().take(2000).collect();
    match level.as_str() {
        "info" => tracing::info!(target: "ui", "{message}"),
        "warn" => tracing::warn!(target: "ui", "{message}"),
        _ => tracing::error!(target: "ui", "{message}"),
    }
}

// --- Last.fm scrobbling ---------------------------------------------------------------------

/// Start the browser auth flow. Returns once the authorize page is open; the outcome (session
/// stored, or an error) arrives via the `lastfm-state` event.
#[tauri::command]
pub async fn lastfm_connect(state: St<'_>) -> Result<(), String> {
    crate::lastfm::connect(state.inner().clone()).await
}

#[tauri::command]
pub async fn lastfm_disconnect(state: St<'_>) -> Result<(), String> {
    crate::lastfm::disconnect(&state);
    Ok(())
}

/// `{ connected, username }` from the persisted session — seeds the titlebar button on mount.
#[tauri::command]
pub async fn lastfm_status(state: St<'_>) -> Result<serde_json::Value, String> {
    Ok(crate::lastfm::status(&state))
}

/// Avatar and counts for the Scrobbling tab's account card. One Last.fm call per tab open.
#[tauri::command]
pub async fn lastfm_profile(state: St<'_>) -> Result<Option<crate::lastfm::Profile>, String> {
    Ok(crate::lastfm::profile(&state).await)
}

/// What `track` would scrobble as under `config` (the Scrobbling tab's unsaved state, as JSON).
/// The tab's preview, computed by the same function the scrobbler sends from, so a pattern the
/// Rust regex engine reads differently from JavaScript's can't make the preview lie.
#[tauri::command]
pub async fn lastfm_preview(
    config: String,
    track: crate::lastfm::Track,
) -> crate::lastfm::Resolved {
    crate::lastfm::resolve(&track, &crate::lastfm::ScrobbleConfig::parse(&config))
}

// --- ListenBrainz scrobbling ------------------------------------------------------------------

// Same scrobbling settings as Last.fm (the shared `lastfm_config` blob); only the account
// differs: a user token pasted from ListenBrainz settings, validated before it is stored.

/// Validate `token` against ListenBrainz and store it. Returns the error rather than emitting
/// it: a pasted token is validated synchronously, unlike Last.fm's browser round-trip.
#[tauri::command]
pub async fn listenbrainz_connect(state: St<'_>, token: String) -> Result<(), String> {
    crate::listenbrainz::connect(state.inner().clone(), token).await
}

#[tauri::command]
pub async fn listenbrainz_disconnect(state: St<'_>) -> Result<(), String> {
    crate::listenbrainz::disconnect(&state);
    Ok(())
}

/// `{ connected, username }` from the persisted token — seeds the Scrobbling tab on mount.
#[tauri::command]
pub async fn listenbrainz_status(state: St<'_>) -> Result<serde_json::Value, String> {
    Ok(crate::listenbrainz::status(&state))
}

/// Listen count for the Scrobbling tab's account card. One ListenBrainz call per tab open.
#[tauri::command]
pub async fn listenbrainz_profile(
    state: St<'_>,
) -> Result<Option<crate::listenbrainz::Profile>, String> {
    Ok(crate::listenbrainz::profile(&state).await)
}

/// Theater mode's fullscreen toggle (#139).
///
/// `setFullscreen` on its own is not enough on Windows. tao decides the client area in
/// WM_NCCALCSIZE: while the real Win32 placement says maximized it clamps the client to the
/// monitor's *work* area, so the "fullscreen" window sits under the taskbar with a frame-thick
/// border around it, and while the window is undecorated-with-shadow it insets the client by the
/// frame thickness. Both are decided before the fullscreen flag is, and tao's own `is_maximized`
/// reads a cached flag that can disagree with the placement, which is why unmaximizing from the
/// UI only fixed it some of the time.
///
/// So: restore from the real placement, go fullscreen, then put the window on the monitor rect
/// with SWP_FRAMECHANGED to force one recalculation with the fullscreen flag set. On the main
/// thread, where the window messages run inline and the order is guaranteed.
///
/// A window that was fullscreen already when theater opened (macOS's green button, a window
/// manager's shortcut) is left alone both ways, so closing theater doesn't drop the user out of a
/// fullscreen they chose (#485).
#[tauri::command]
pub fn theater_fullscreen(window: tauri::WebviewWindow, on: bool) -> Result<(), String> {
    use std::sync::atomic::{AtomicBool, Ordering};

    static WAS_FULLSCREEN: AtomicBool = AtomicBool::new(false);
    if on {
        let already = window.is_fullscreen().unwrap_or(false);
        WAS_FULLSCREEN.store(already, Ordering::Relaxed);
        if already {
            return Ok(());
        }
    } else if WAS_FULLSCREEN.swap(false, Ordering::Relaxed) {
        return Ok(());
    }

    #[cfg(not(target_os = "windows"))]
    {
        window.set_fullscreen(on).map_err(|e| e.to_string())
    }
    #[cfg(target_os = "windows")]
    {
        use windows::Win32::UI::WindowsAndMessaging::{
            IsZoomed, SetWindowPos, ShowWindow, SWP_FRAMECHANGED, SWP_NOMOVE, SWP_NOSIZE,
            SWP_NOZORDER, SW_MAXIMIZE, SW_RESTORE,
        };

        /// Restoring the window is what makes fullscreen work, so theater has to put the
        /// maximized state back itself on the way out.
        static WAS_MAXIMIZED: AtomicBool = AtomicBool::new(false);

        let w = window.clone();
        window
            .run_on_main_thread(move || {
                let Ok(hwnd) = w.hwnd() else { return };
                if on {
                    let zoomed = unsafe { IsZoomed(hwnd).as_bool() };
                    WAS_MAXIMIZED.store(zoomed, Ordering::Relaxed);
                    if zoomed {
                        unsafe {
                            let _ = ShowWindow(hwnd, SW_RESTORE);
                        }
                    }
                    let _ = w.set_fullscreen(true);
                    if let Ok(Some(m)) = w.current_monitor() {
                        let (p, s) = (m.position(), m.size());
                        unsafe {
                            let _ = SetWindowPos(
                                hwnd,
                                None,
                                p.x,
                                p.y,
                                s.width as i32,
                                s.height as i32,
                                SWP_FRAMECHANGED | SWP_NOZORDER,
                            );
                        }
                    }
                } else {
                    let _ = w.set_fullscreen(false);
                    if WAS_MAXIMIZED.swap(false, Ordering::Relaxed) {
                        unsafe {
                            let _ = ShowWindow(hwnd, SW_MAXIMIZE);
                        }
                    }
                    unsafe {
                        let _ = SetWindowPos(
                            hwnd,
                            None,
                            0,
                            0,
                            0,
                            0,
                            SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER,
                        );
                    }
                }
            })
            .map_err(|e| e.to_string())
    }
}

#[tauri::command]
pub fn get_matugen_theme(app: tauri::AppHandle) -> Result<Option<String>, String> {
    crate::matugen::read(&app)
}

#[tauri::command]
pub fn start_matugen_watcher(app: tauri::AppHandle) -> Result<(), String> {
    crate::matugen::start(app)
}

#[tauri::command]
pub fn stop_matugen_watcher() {
    crate::matugen::stop();
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn on_repeat_rows_shed_the_queue_slot_they_were_played_from() {
        let played = SongItem {
            video_id: "abc".into(),
            title: "Grace".into(),
            queued: true,
            queued_by: Some("simohypers".into()),
            autoplay: true,
            set_video_id: Some("SVI".into()),
            ..Default::default()
        };
        let row = shed_queue_context(played.clone());
        assert_eq!(
            row,
            SongItem { video_id: "abc".into(), title: "Grace".into(), ..Default::default() }
        );
        assert_eq!(row.title, played.title, "the song itself survives");
    }
}
