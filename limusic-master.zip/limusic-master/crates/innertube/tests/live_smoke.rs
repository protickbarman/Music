//! Live-YouTube extraction smoke test (context/17). NOT in the default run:
//!   cargo test -p innertube --features integration-tests -- --nocapture
#![cfg(feature = "integration-tests")]

use innertube::{
    find_format, AudioQuality, Clients, InnerTube, PlaylistSort, Session, STREAM_FALLBACK_ORDER,
};

const VIDEO_ID: &str = "xl9cFAOKg_Y"; // the id from the user's failing run

/// Can this URL serve the whole track?
///
/// Two ranges, because one is not enough. The opening range is what the player reads first; the
/// tail is the one question that catches a capped URL, and since 2026 googlevideo answers some
/// URLs only for ranges ending inside the first mebibyte (KNOWN-ISSUES KI-11). A probe of the
/// first kilobyte alone, which is what this used to be, passes on exactly the streams that
/// delivered nothing to the user in issue #292.
///
/// `Accept-Encoding: identity` on both: a range and a content-encoding do not mix, and this is
/// also the shape `src-tauri/src/audioproxy.rs` fetches with in the real app.
async fn probe(
    url: &str,
    ua: Option<&str>,
    size: Option<u64>,
) -> (reqwest::StatusCode, Option<reqwest::StatusCode>) {
    let client = reqwest::Client::new();
    let get = |range: String| {
        let mut req = client.get(url).header("Range", range).header("Accept-Encoding", "identity");
        if let Some(ua) = ua {
            req = req.header("User-Agent", ua);
        }
        req
    };
    let head = get("bytes=0-1023".to_owned()).send().await.expect("opening probe").status();
    let tail = match size.filter(|n| *n > 1024) {
        Some(n) => Some(
            get(format!("bytes={}-{}", n - 256, n - 1)).send().await.expect("tail probe").status(),
        ),
        None => None,
    };
    (head, tail)
}

/// What happened to one client on this run. Printed as a matrix so a nightly run says which leg
/// of the chain moved, not just whether something still worked: the old "any client worked"
/// check stayed green through every breakage this project has had, because VISIONOS kept
/// answering while everything else died around it (KNOWN-ISSUES KI-12).
#[derive(Debug)]
#[allow(dead_code)] // the payloads are read through `Debug` only
enum Leg {
    /// Resolved and served both the opening and the tail.
    Streams(i32),
    /// Resolved, but googlevideo will not serve the whole file (the KI-11 cap).
    Capped(i32),
    /// Needs the cipher and a minted PoToken, which live in `limusic-app`, not here.
    NotTestableHere,
    Failed(String),
}

/// The clients this test asserts on. A direct-URL client in `STREAM_FALLBACK_ORDER` that stops
/// streaming a whole track is the event this whole test exists to catch: KI-12 records that only
/// three identities still play one, and this is the only one of the three testable from this
/// crate. When it goes red, read KI-12's "The check" section.
const MUST_STREAM: [&str; 1] = ["VISIONOS"];

#[tokio::test]
async fn direct_clients_resolve_and_stream() {
    let it = InnerTube::new(Session::default(), None).unwrap();
    let vd = match it.fetch_visitor_data().await {
        Ok(v) => {
            eprintln!("visitorData: {} chars", v.len());
            Some(v)
        }
        Err(e) => {
            eprintln!("visitorData bootstrap FAILED: {e}");
            None
        }
    };
    let it = InnerTube::new(Session { visitor_data: vd, ..Session::default() }, None).unwrap();
    let clients = Clients::bundled();

    let mut matrix: Vec<(&str, Leg)> = Vec::new();
    for key in STREAM_FALLBACK_ORDER {
        let client = clients.get(key).unwrap();
        // A PoToken client cannot be resolved from this crate: it needs a minted token, a
        // signature timestamp and the cipher, all of which live in the app. This test covers the
        // direct half of the chain, which is the half that must keep working with those gone.
        if client.use_web_po_tokens {
            matrix.push((key, Leg::NotTestableHere));
            continue;
        }
        let resp = match it.player(client, VIDEO_ID, None, None, None).await {
            Ok(r) => r,
            Err(e) => {
                matrix.push((key, Leg::Failed(format!("/player failed: {e}"))));
                continue;
            }
        };
        if !resp.playability_status.is_ok() {
            matrix.push((
                key,
                Leg::Failed(format!(
                    "status {} ({})",
                    resp.playability_status.status,
                    resp.playability_status.reason.as_deref().unwrap_or("no reason")
                )),
            ));
            continue;
        }
        let sd = resp.streaming_data.as_ref().expect("streamingData");
        assert!(sd.expires_in_seconds.is_some(), "{key}: expiry must parse");
        let Some(format) = find_format(sd, AudioQuality::High) else {
            matrix.push((key, Leg::Failed("no audio format".into())));
            continue;
        };
        let Some(url) = format.direct_url() else {
            matrix.push((key, Leg::Failed(format!("itag {} cipher-only", format.itag))));
            continue;
        };
        let size = format.content_length.as_deref().and_then(|n| n.parse().ok());
        let leg = match probe(url, Some(&client.user_agent), size).await {
            (head, Some(tail)) if head.is_success() && tail.is_success() => {
                Leg::Streams(format.itag)
            }
            (head, Some(_)) if head.is_success() => Leg::Capped(format.itag),
            (head, None) if head.is_success() => {
                Leg::Failed(format!("itag {}: no contentLength, tail not checked", format.itag))
            }
            (head, tail) => {
                Leg::Failed(format!("itag {}: HTTP {head}, tail {tail:?}", format.itag))
            }
        };
        matrix.push((key, leg));
    }

    for (key, leg) in &matrix {
        eprintln!("{key}: {leg:?}");
    }
    for key in MUST_STREAM {
        assert!(
            matches!(matrix.iter().find(|(k, _)| *k == key).map(|(_, l)| l), Some(Leg::Streams(_))),
            "{key} no longer streams a whole track. This is a YouTube-side change, not a code \
             regression, and it may leave nothing in the chain that plays (issue #292)."
        );
    }
}

/// Live regression for the "load more duplicates tracks" bug: an owned playlist's continuation
/// embeds a nested duplicate renderer per row. Self-skips unless a real session is supplied:
///   LIMUSIC_COOKIE=… LIMUSIC_VISITOR=… cargo test -p innertube --features integration-tests owned_continuation_not_doubled -- --ignored --nocapture
#[tokio::test]
#[ignore]
async fn owned_continuation_not_doubled() {
    let Some(cookie) = std::env::var("LIMUSIC_COOKIE").ok().filter(|s| !s.is_empty()) else {
        eprintln!("skipped: set LIMUSIC_COOKIE (+LIMUSIC_VISITOR) to run");
        return;
    };
    let visitor = std::env::var("LIMUSIC_VISITOR").ok().filter(|s| !s.is_empty());
    let it = InnerTube::new(
        Session { cookie: Some(cookie), visitor_data: visitor, ..Session::default() },
        None,
    )
    .unwrap();
    let clients = Clients::bundled();
    let client = clients.get("WEB_REMIX").expect("WEB_REMIX client");

    let libs = it.library_playlists(client).await.expect("library playlists");
    let mut checked = 0;
    for c in &libs {
        let Ok(page) = it.playlist(client, &c.id, None).await else { continue };
        let Some(tok) = page.continuation.clone() else { continue };
        let cont = it.playlist_continuation(client, &tok).await.expect("continuation");
        if cont.items.is_empty() {
            continue; // a suggestions carousel, not more tracks
        }
        checked += 1;
        let mut seen = std::collections::HashSet::new();
        for i in &cont.items {
            assert!(
                seen.insert(i.video_id.clone()),
                "playlist '{}' owned={} continuation doubled video {}",
                page.title.clone().unwrap_or_default(),
                page.owned,
                i.video_id
            );
        }
    }
    assert!(checked > 0, "no playlist with a track continuation found to verify");
    eprintln!("verified {checked} track continuations, no doubling");
}

/// Issue #72: the library grids come back ~25 at a time, so a single browse truncated any bigger
/// library. Asserts the grids page past one response, on an account that has more than one page.
///   LIMUSIC_COOKIE=… LIMUSIC_VISITOR=… cargo test -p innertube --features integration-tests library_grids_page -- --ignored --nocapture
#[tokio::test]
#[ignore]
async fn library_grids_page_past_the_first_response() {
    let Some(cookie) = std::env::var("LIMUSIC_COOKIE").ok().filter(|s| !s.is_empty()) else {
        eprintln!("skipped: set LIMUSIC_COOKIE (+LIMUSIC_VISITOR) to run");
        return;
    };
    let visitor = std::env::var("LIMUSIC_VISITOR").ok().filter(|s| !s.is_empty());
    let it = InnerTube::new(
        Session { cookie: Some(cookie), visitor_data: visitor, ..Session::default() },
        None,
    )
    .unwrap();
    let clients = Clients::bundled();
    let client = clients.get("WEB_REMIX").expect("WEB_REMIX client");

    let mut paged = 0;
    for (name, items) in [
        ("playlists", it.library_playlists(client).await.expect("library playlists")),
        ("albums", it.library_albums(client).await.expect("library albums")),
        ("artists", it.library_artists(client).await.expect("library artists")),
    ] {
        eprintln!("{name}: {} items", items.len());
        let mut seen = std::collections::HashSet::new();
        for i in &items {
            assert!(seen.insert(i.id.clone()), "{name} grid repeated {} across pages", i.id);
        }
        if items.len() > 25 {
            paged += 1;
        }
    }
    assert!(paged > 0, "no library grid exceeded one page — test this on a fuller account");
}

/// The playlist sort is YouTube's, not ours: the app asks for an order and renders what comes back
/// (`PlaylistSort::params`). Those params are a protobuf literal copied out of YouTube's own menu,
/// so this pins the half that moves under us — that they still sort, and that the menu still says
/// which order the list is in and whether the choice can be written back.
///
/// Read-only on purpose. The write side (`playlist_set_sort`) changes a real playlist for every
/// client on the account, so it is not something a test suite should do behind your back.
///   LIMUSIC_COOKIE=… LIMUSIC_VISITOR=… cargo test -p innertube --features integration-tests playlist_sort -- --ignored --nocapture
#[tokio::test]
#[ignore]
async fn playlist_sort_params_still_order_the_server_side_list() {
    let Some(cookie) = std::env::var("LIMUSIC_COOKIE").ok().filter(|s| !s.is_empty()) else {
        eprintln!("skipped: set LIMUSIC_COOKIE (+LIMUSIC_VISITOR) to run");
        return;
    };
    let visitor = std::env::var("LIMUSIC_VISITOR").ok().filter(|s| !s.is_empty());
    let it = InnerTube::new(
        Session { cookie: Some(cookie), visitor_data: visitor, ..Session::default() },
        None,
    )
    .unwrap();
    let clients = Clients::bundled();
    let client = clients.get("WEB_REMIX").expect("WEB_REMIX client");

    // Liked Music is the one list every account has, and YouTube sorts it without being asked to
    // store anything on a playlist.
    let plain = it.playlist(client, "VLLM", None).await.expect("liked music");
    let menu = plain.sort_menu.clone().expect("Liked Music still offers a sort menu");
    assert!(!menu.editable, "Liked Music sorts through browse params, not a playlist edit");
    assert!(plain.items.len() > 1, "need more than one track to tell an order from another");

    let titles = |p: &innertube::PlaylistPage| -> Vec<String> {
        p.items.iter().map(|i| i.title.clone()).collect()
    };
    let asc = it.playlist(client, "VLLM", Some((PlaylistSort::Title, false))).await.expect("A-Z");
    let desc = it.playlist(client, "VLLM", Some((PlaylistSort::Title, true))).await.expect("Z-A");
    assert_eq!(
        asc.sort_menu.as_ref().and_then(|m| m.selected),
        Some(PlaylistSort::Title),
        "the menu has to report back the order we asked for"
    );
    assert_ne!(titles(&asc), titles(&desc), "descending params must not return the same page");
    assert_ne!(titles(&asc), titles(&plain), "a title sort must not return the stored order");

    // Put Liked Music back: asking for an order is what persists it on this one list.
    let restored = it.playlist(client, "VLLM", Some((PlaylistSort::Default, false))).await;
    assert!(restored.is_ok(), "failed to restore Liked Music to its stored order");
    eprintln!("title sort verified against {} tracks, Liked Music restored", plain.items.len());
}

/// Every surface has to hand the queue an artist that is a *name*. That string is the player bar,
/// the OS media widget, Discord, and the Last.fm scrobble, so the two bad shapes are: nothing at all
/// (YouTube ships the per-track artist column empty on single-artist albums, `"text": {}`, because
/// the header names the artist) and a whole display subtitle ("Aqua • 1.7B views" off a song card).
/// The unit tests pin how we parse a fixture; this pins the shape YouTube actually sends, which is
/// the half that moves under us.
///   cargo test -p innertube --features integration-tests every_surface -- --nocapture
#[tokio::test]
async fn every_surface_yields_a_scrobbleable_artist() {
    /// Mirrors `lastfm::scrobbleable` plus the "•" tell: a real artist line separates collabs with
    /// "&" or ",", never a bullet, so a bullet means a display string leaked into the field.
    fn bad(artist: &str) -> Option<&'static str> {
        match artist {
            a if a.trim().is_empty() => Some("no artist (would never scrobble)"),
            a if a.contains('•') => {
                Some("display subtitle, not an artist (would scrobble wrong)")
            }
            _ => None,
        }
    }

    let it = InnerTube::new(Session::default(), None).unwrap();
    let vd = it.fetch_visitor_data().await.ok();
    let it = InnerTube::new(Session { visitor_data: vd, ..Session::default() }, None).unwrap();
    let clients = Clients::bundled();
    let c = clients.get(innertube::METADATA_CLIENT).expect("metadata client");

    let mut problems: Vec<String> = Vec::new();
    let mut checked = 0usize;
    let note = |problems: &mut Vec<String>, surface: &str, title: &str, artist: &str| {
        if let Some(why) = bad(artist) {
            problems.push(format!("{surface}: {title:?} → {artist:?} ({why})"));
        }
    };

    // Single-artist albums: the case that shipped broken. Compilations keep a per-row artist, so
    // these are deliberately all one-artist records.
    for q in ["Rumours Fleetwood Mac", "Midnights Taylor Swift", "IGOR Tyler The Creator"] {
        let cards = it.search_cards(c, q, "albums").await.expect("album search");
        let Some(card) = cards.iter().find(|b| b.kind == "album") else {
            problems.push(format!("album search {q:?} returned no album card"));
            continue;
        };
        let album = it.album(c, &card.id).await.expect("album page");
        assert!(!album.items.is_empty(), "album {q:?} parsed with no tracks");
        for t in &album.items {
            checked += 1;
            note(&mut problems, &format!("album {:?}", card.title), &t.title, &t.artists);
        }
    }

    // Search rows, the up-next queue, and an artist page (top songs + every song card in its
    // carousels, which is where the "• 1.7B views" strings came from).
    let songs = it.search_songs(c, "Barbie Girl Aqua", false).await.expect("search");
    for t in songs.items.iter().take(5) {
        checked += 1;
        note(&mut problems, "search", &t.title, &t.artists);
    }
    if let Some(first) = songs.items.first() {
        for t in it.next(c, Some(&first.video_id), None).await.expect("next").items.iter().take(5) {
            checked += 1;
            note(&mut problems, "queue", &t.title, &t.artists);
        }
    }
    let found = it.search_all(c, "Aqua", false).await.expect("search_all");
    if let Some(artist) = found.artists.first() {
        let page = it.artist(c, &artist.id).await.expect("artist page");
        for t in &page.top_songs {
            checked += 1;
            note(&mut problems, "artist top songs", &t.title, &t.artists);
        }
        for carousel in &page.sections {
            for card in carousel.items.iter().filter(|i| i.kind == "song") {
                checked += 1;
                let sub = card.subtitle.clone().unwrap_or_default();
                note(&mut problems, &format!("card {:?}", carousel.title), &card.title, &sub);
            }
        }
    }

    assert!(
        checked > 40,
        "only {checked} tracks reached the check, so the surfaces came back empty"
    );
    assert!(
        problems.is_empty(),
        "{checked} tracks checked, {} unscrobbleable:\n  {}",
        problems.len(),
        problems.join("\n  ")
    );
    eprintln!("{checked} tracks across album / search / queue / artist surfaces, all with a usable artist");
}

#[tokio::test]
async fn rustypipe_url_is_fetchable() {
    let c =
        innertube::rustypipe_fallback::resolve(VIDEO_ID, true).await.expect("rustypipe resolve");
    let (bare, _) = probe(&c.url, None, None).await;
    eprintln!("rustypipe itag {}: no-UA -> HTTP {bare}", c.itag);
    // mpv sends its own libmpv UA by default; also probe with a browser-ish UA for comparison.
    let (browser, _) = probe(&c.url, Some("Mozilla/5.0 (X11; Linux x86_64)"), None).await;
    eprintln!("rustypipe itag {}: browser-UA -> HTTP {browser}", c.itag);
    assert!(
        bare.is_success() || browser.is_success(),
        "rustypipe URL not fetchable (Raw(-13) root cause)"
    );
}

/// Radio (context/08) is a prefix convention plus one `/next` call, and every part of that is an
/// assumption about YouTube's wire behaviour rather than something a fixture can prove. This
/// checks the three the feature stands on:
///   1. `RDAMVM<videoId>` returns a real queue, not just the seed song.
///   2. `/next` accepts a radio playlist with **no** videoId (how artist radio has to be asked for).
///   3. An artist page still carries a start-radio button to get that playlist id from.
#[tokio::test]
async fn radio_seeds_resolve() {
    let it = InnerTube::new(Session::default(), None).unwrap();
    let vd = it.fetch_visitor_data().await.ok();
    let it = InnerTube::new(Session { visitor_data: vd, ..Session::default() }, None).unwrap();
    let client = Clients::bundled().get(innertube::METADATA_CLIENT).unwrap().clone();

    // 1. Song radio.
    let song = it
        .next(&client, Some(VIDEO_ID), Some(&format!("RDAMVM{VIDEO_ID}")))
        .await
        .expect("song radio /next");
    eprintln!("RDAMVM{VIDEO_ID}: {} tracks", song.items.len());
    assert!(song.items.len() > 1, "song radio came back with only the seed");

    // 2. + 3. Artist radio: the id off the page, then a videoId-less /next with it.
    let artist_id = song.items[0].artist_id.clone().expect("radio rows link their artist");
    let page = it.artist(&client, &artist_id).await.expect("artist page");
    let radio = page.radio_playlist_id.expect("artist header has no start-radio button");
    eprintln!("artist {:?} radio: {radio}", page.name);
    let artist_radio = it.next(&client, None, Some(&radio)).await.expect("artist radio /next");
    eprintln!("{radio}: {} tracks", artist_radio.items.len());
    assert!(artist_radio.items.len() > 1, "playlist-only /next returned nothing");

    // 4. Album radio: `RDAMPL` over the album's *audio* playlist, again with no videoId.
    let album_id =
        song.items.iter().find_map(|i| i.album_id.clone()).expect("a radio row with an album");
    let album = it.album(&client, &album_id).await.expect("album page");
    // Issue #105: the rows themselves never carry it, so `album()` stamps its own id on them.
    // Without that, a track played off a release page has no "Go to album" in its menu.
    assert!(
        album.items.iter().all(|i| i.album_id.as_deref() == Some(album_id.as_str())),
        "album rows reached the queue without the album's id"
    );
    let pl = album.playlist_id.expect("album has no audio playlist");
    let album_radio =
        it.next(&client, None, Some(&format!("RDAMPL{pl}"))).await.expect("album radio /next");
    eprintln!("RDAMPL{pl}: {} tracks", album_radio.items.len());
    assert!(album_radio.items.len() > 1, "album radio came back empty");
}

/// Issue #73: the Library's Songs tab is a plain browse of `FEmusic_liked_videos` read back through
/// the playlist parser (that browseId is YouTube's own Library ▸ Songs, despite the name). Nothing
/// else in the app touches it, so this is what says whether YouTube still answers it with a track
/// shelf and a paging token.
///   LIMUSIC_COOKIE=… LIMUSIC_VISITOR=… cargo test -p innertube --features integration-tests library_songs -- --ignored --nocapture
#[tokio::test]
#[ignore]
async fn library_songs_browse_returns_tracks() {
    let Some(cookie) = std::env::var("LIMUSIC_COOKIE").ok().filter(|s| !s.is_empty()) else {
        eprintln!("skipped: set LIMUSIC_COOKIE (+LIMUSIC_VISITOR) to run");
        return;
    };
    let visitor = std::env::var("LIMUSIC_VISITOR").ok().filter(|s| !s.is_empty());
    let it = InnerTube::new(
        Session { cookie: Some(cookie), visitor_data: visitor, ..Session::default() },
        None,
    )
    .unwrap();
    let clients = Clients::bundled();
    let client = clients.get("WEB_REMIX").expect("WEB_REMIX client");

    let page = it.playlist(client, "FEmusic_liked_videos", None).await.expect("library songs");
    eprintln!(
        "{} songs, continuation: {}, sort menu: {:?}, title: {:?}, subtitle: {:?}",
        page.items.len(),
        page.continuation.is_some(),
        page.sort_menu,
        page.title,
        page.subtitle
    );
    assert!(!page.items.is_empty(), "no tracks came back — is the account's library empty?");
    for i in &page.items {
        assert!(!i.video_id.is_empty(), "row {:?} has no videoId", i.title);
    }
    let mut seen = std::collections::HashSet::new();
    for i in &page.items {
        assert!(seen.insert(i.video_id.clone()), "first page repeated {}", i.video_id);
    }
    if let Some(t) = &page.continuation {
        let more = it.playlist_continuation(client, t).await.expect("continuation");
        eprintln!("continuation: {} more songs", more.items.len());
        assert!(!more.items.is_empty(), "the paging token resolved to nothing");
    }
}

/// "Add to library" on a song is a `feedbackEndpoint` token minted on the row itself, not a rating,
/// so the whole feature stands on rows still arriving with that menu. It is invisible if it breaks:
/// no tokens simply means the menu never offers the action. Reports what each surface carried, and
/// dumps a row's actual menu when nothing matched, since the shape is the thing in question.
///   LIMUSIC_COOKIE=… LIMUSIC_VISITOR=… cargo test -p innertube --features integration-tests library_tokens -- --ignored --nocapture
#[tokio::test]
#[ignore]
async fn song_rows_carry_library_tokens() {
    let Some(cookie) = std::env::var("LIMUSIC_COOKIE").ok().filter(|s| !s.is_empty()) else {
        eprintln!("skipped: set LIMUSIC_COOKIE (+LIMUSIC_VISITOR) to run");
        return;
    };
    let visitor = std::env::var("LIMUSIC_VISITOR").ok().filter(|s| !s.is_empty());
    let it = InnerTube::new(
        Session { cookie: Some(cookie), visitor_data: visitor, ..Session::default() },
        None,
    )
    .unwrap();
    let clients = Clients::bundled();
    let client = clients.get("WEB_REMIX").expect("WEB_REMIX client");

    // Every menu entry of the first song row, as YouTube sends it: renderer name, icon, and which
    // kind of endpoint hangs off it. That is exactly the information the parser matches on.
    fn dump_menu(label: &str, row: &serde_json::Value) {
        let Some(menu) = row.get("menu") else {
            let keys: Vec<&str> =
                row.as_object().map(|o| o.keys().map(String::as_str).collect()).unwrap_or_default();
            eprintln!("  {label}: no menu on this row. keys: {keys:?}");
            return;
        };
        eprintln!("  {label} menu:");
        for item in
            menu.pointer("/menuRenderer/items").and_then(|i| i.as_array()).unwrap_or(&vec![])
        {
            let Some((renderer, body)) = item.as_object().and_then(|o| o.iter().next()) else {
                continue;
            };
            let icon = |k: &str| {
                body.pointer(&format!("/{k}/iconType")).and_then(|v| v.as_str()).unwrap_or("-")
            };
            let text = body
                .pointer("/text/runs/0/text")
                .or_else(|| body.pointer("/defaultText/runs/0/text"))
                .and_then(|v| v.as_str())
                .unwrap_or("-");
            let endpoints: Vec<&str> = body
                .as_object()
                .map(|o| o.keys().filter(|k| k.contains("Endpoint")).map(String::as_str).collect())
                .unwrap_or_default();
            eprintln!(
                "    {renderer}: text={text:?} icon={} default={} toggled={} endpoints={endpoints:?} feedback={}",
                icon("icon"),
                icon("defaultIcon"),
                icon("toggledIcon"),
                serde_json::to_string(body).unwrap_or_default().contains("feedbackEndpoint")
            );
        }
    }

    let raw = it.search_json(client, "daft punk", Some("EgWKAQIIAWoKEAkQBRAKEAMQBA%3D%3D")).await;
    let search = it.search_songs(client, "daft punk", false).await.expect("search");
    let with_tokens = search.items.iter().filter(|s| s.library.is_some()).count();
    eprintln!("search: {}/{} rows carry a library action", with_tokens, search.items.len());
    if with_tokens == 0 {
        if let Ok(raw) = &raw {
            let rows = find_rows(raw, "musicResponsiveListItemRenderer");
            eprintln!(
                "  {} raw search rows; feedbackToken anywhere in the response: {}",
                rows.len(),
                serde_json::to_string(raw).unwrap_or_default().contains("feedbackToken")
            );
            if let Some(row) = rows.iter().find(|r| r.get("menu").is_some()).or(rows.first()) {
                dump_menu("search row", row);
            }
        }
    }

    // Search is the surface this feature lives on: every row there carried the toggle when this was
    // written (20/20, 2026-08-28). Zero means the menu shape moved again, and the dump above says how.
    assert!(with_tokens > 0, "no search row carried a library action — the menu shape changed");

    // Library ▸ Songs rows come from a browse, a different response with its own menus. Most of
    // them ship without a menu at all, so this half only reports: it is not a guard.
    // Note the rows that do carry one report `in_library: false` — that list is your *liked*
    // songs, and liking is not the same write as saving to the library.
    let page = it.playlist(client, "FEmusic_liked_videos", None).await.expect("library songs");
    let saved = page.items.iter().filter(|s| s.library.is_some()).count();
    let already =
        page.items.iter().filter(|s| s.library.as_ref().is_some_and(|l| l.in_library)).count();
    eprintln!(
        "library songs: {}/{} carry an action, {} report in_library",
        saved,
        page.items.len(),
        already
    );
    if saved == 0 {
        if let Ok(raw) = it.browse_json(client, "FEmusic_liked_videos").await {
            let rows = find_rows(&raw, "musicResponsiveListItemRenderer");
            eprintln!("  {} raw library rows", rows.len());
            if let Some(row) = rows.iter().find(|r| r.get("menu").is_some()).or(rows.first()) {
                dump_menu("library row", row);
            }
        }
    }
    if let Some(song) = page.items.iter().find(|s| s.library.is_some()) {
        let lib = song.library.as_ref().unwrap();
        eprintln!(
            "  {:?}: in_library={} add={:?} remove={:?}",
            song.title,
            lib.in_library,
            lib.add_token.as_deref().map(|t| &t[..t.len().min(12)]),
            lib.remove_token.as_deref().map(|t| &t[..t.len().min(12)])
        );
    }
}

/// Every `key` node in the tree, in document order (the crate keeps its own walker private).
fn find_rows<'a>(root: &'a serde_json::Value, key: &str) -> Vec<&'a serde_json::Value> {
    let mut out = Vec::new();
    fn walk<'a>(v: &'a serde_json::Value, key: &str, out: &mut Vec<&'a serde_json::Value>) {
        match v {
            serde_json::Value::Object(map) => {
                for (k, val) in map {
                    if k == key {
                        out.push(val);
                    }
                    walk(val, key, out);
                }
            }
            serde_json::Value::Array(arr) => arr.iter().for_each(|e| walk(e, key, out)),
            _ => {}
        }
    }
    walk(root, key, &mut out);
    out
}

/// Issues #209 / #266: the Videos shelf. `FILTER_SONG` cannot return a cover, a live set or a fan
/// remix, so the shelf rides on a second search with `FILTER_VIDEO`, and the only thing that says
/// that param is still the video filter is YouTube answering it with video rows. Live, so ignored:
///   cargo test -p innertube --features integration-tests video_search -- --ignored --nocapture
#[tokio::test]
#[ignore]
async fn video_search_returns_video_rows() {
    let it = InnerTube::new(Session::default(), None).unwrap();
    let vd = it.fetch_visitor_data().await.ok();
    let it = InnerTube::new(Session { visitor_data: vd, ..Session::default() }, None).unwrap();
    let client = Clients::bundled().get(innertube::METADATA_CLIENT).unwrap().clone();

    let videos = it.search_videos(&client, "daft punk").await.expect("video search");
    let tagged = videos.items.iter().filter(|s| s.is_video).count();
    eprintln!("video search: {} rows, {} tagged is_video", videos.items.len(), tagged);
    for s in videos.items.iter().take(3) {
        eprintln!("  {:?} - {:?} ({:?})", s.title, s.artists, s.duration);
    }
    assert!(!videos.items.is_empty(), "FILTER_VIDEO returned nothing — the param moved");
    // Every row of a video-filtered search is a video. Anything less means `musicVideoType` moved
    // and the "hide music videos" setting is leaking videos through this shelf.
    assert_eq!(tagged, videos.items.len(), "a video-filtered row was not tagged is_video");

    // The setting is a refusal to ask, not a filter on the rows: nothing to leak.
    it.set_hide_videos(true);
    let hidden = it.search_videos(&client, "daft punk").await.expect("hidden video search");
    assert!(hidden.items.is_empty(), "hide_videos did not empty the video search");
}

/// Is the rustypipe safety net still able to carry a whole track?
///
/// Measured 2026-09-22: googlevideo serves the first mebibyte of a rustypipe URL and 403s any
/// range ending past it, at any chunk size, on every video tried. mpv played nothing and blamed
/// the audio format (issue #292), and `Orchestrator::streams_to_the_end` now rejects such a URL
/// rather than hand it over. **A failure here means the net is down, not that the code broke**:
/// the app degrades to "nothing could play this", so what is lost is the last resort.
#[tokio::test]
async fn rustypipe_url_streams_to_the_end() {
    let c =
        innertube::rustypipe_fallback::resolve(VIDEO_ID, true).await.expect("rustypipe resolve");
    assert!(c.size > 1024 * 1024, "pick a longer VIDEO_ID: this one fits inside the cap");
    let resp = reqwest::Client::new()
        .get(&c.url)
        .header("Range", format!("bytes={}-{}", c.size - 256, c.size - 1))
        .header("Accept-Encoding", "identity")
        .send()
        .await
        .expect("range request");
    eprintln!("rustypipe itag {}: last 256 B -> HTTP {}", c.itag, resp.status());
    assert!(resp.status().is_success(), "rustypipe URL serves only its first MiB (issue #292)");
}

/// The two community registries `src-tauri/src/cipher/config.rs` reads. Duplicated here on purpose:
/// they live in `limusic-app`, which this crate cannot depend on, and a nightly that had to build
/// libmpv and WebKitGTK to check a JSON file would not be run.
// ponytail: hand-synced with `cipher::config::REGISTRY_URLS`. If that list ever changes, change
// this; the cost of being wrong is a false red on a nightly, not a shipped bug.
const REGISTRY_URLS: [&str; 2] = [
    "https://raw.githubusercontent.com/ZemerTeam/zemer-cipher/master/library/src/main/assets/player_configs.json",
    "https://raw.githubusercontent.com/MetrolistGroup/faraday/master/registry/player_configs.json",
];

/// The player hash in `iframe_api`, the way `cipher::fetcher::extract_hash` finds it. A string
/// search rather than a regex: `regex` is not a dependency of this crate and a test is not a
/// reason to add one. The URL's slashes may be backslash-escaped in the JS source.
fn player_hash(iframe_api_js: &str) -> Option<String> {
    let at = ["/s/player/", r"\/s\/player\/"]
        .iter()
        .find_map(|needle| iframe_api_js.find(needle).map(|i| i + needle.len()))?;
    let rest = &iframe_api_js[at..];
    let end = rest.find(|c: char| !(c.is_ascii_alphanumeric() || c == '_' || c == '-'))?;
    (end > 0).then(|| rest[..end].to_owned())
}

#[test]
fn player_hash_reads_both_url_shapes() {
    assert_eq!(
        player_hash(r#"var u='https:\/\/www.youtube.com\/s\/player\/4918c89a\/www-widgetapi.js';"#)
            .as_deref(),
        Some("4918c89a")
    );
    assert_eq!(
        player_hash("https://www.youtube.com/s/player/abcd1234/base.js").as_deref(),
        Some("abcd1234")
    );
    assert_eq!(player_hash("no player here"), None);
}

/// Do the cipher registries carry a config for the `player.js` YouTube is serving right now?
///
/// Every ciphered client (WEB_REMIX, TVHTML5_SIMPLY, WEB_CREATOR) depends on this, and static
/// extraction of the sig and `n` functions is dead on the 2025+ VM-dispatch players, so the
/// registries are the only way in (`src-tauri/src/cipher/config.rs:4-7`). A red here means YouTube
/// has rotated and the registries have not caught up: the app degrades to VISIONOS alone until
/// they do. **That is a YouTube-side event, not a code regression.**
#[tokio::test]
async fn cipher_registries_cover_the_current_player() {
    let js = reqwest::Client::new()
        .get("https://www.youtube.com/iframe_api")
        .header(
            "User-Agent",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) \
             Chrome/131.0.0.0 Safari/537.36",
        )
        .send()
        .await
        .expect("iframe_api")
        .text()
        .await
        .expect("iframe_api body");
    let hash = player_hash(&js).expect("player hash in iframe_api");
    eprintln!("current player hash: {hash}");

    let mut covered_by: Vec<&str> = Vec::new();
    for url in REGISTRY_URLS {
        let Ok(resp) = reqwest::Client::new().get(url).send().await else {
            eprintln!("{url}: unreachable");
            continue;
        };
        let Ok(body) = resp.text().await else { continue };
        let Ok(v) = serde_json::from_str::<serde_json::Value>(&body) else {
            eprintln!("{url}: not JSON");
            continue;
        };
        let players = v.get("players").and_then(|p| p.as_object());
        let hit = players.is_some_and(|p| {
            p.contains_key(&hash)
                || p.values().any(|e| {
                    e.get("aliases")
                        .and_then(|a| a.as_array())
                        .is_some_and(|a| a.iter().any(|x| x.as_str() == Some(hash.as_str())))
                })
        });
        eprintln!("{url}: {}", if hit { "has it" } else { "does not have it" });
        if hit {
            covered_by.push(url);
        }
    }
    assert!(
        !covered_by.is_empty(),
        "no cipher registry has a config for player {hash}. WEB_REMIX and TVHTML5_SIMPLY cannot \
         decipher until one publishes it; the app re-checks on its own every 15 minutes, and \
         VISIONOS alone carries playback meanwhile."
    );
}

/// Comments load for an audio track (ATV) and for a music video, and page. A track with comments
/// turned off reads as `Disabled` and is skipped, since that is the track's choice and not a
/// breakage. What breaks it is the response shape moving: the Comments tab token, the
/// entity join, or the header's sort entries.
#[tokio::test]
async fn comments_load_for_an_audio_track_and_a_video() {
    use innertube::{CommentSortKey, CommentsState};

    let it = InnerTube::new(Session::default(), None).unwrap();
    let vd = it.fetch_visitor_data().await.ok();
    let it = InnerTube::new(Session { visitor_data: vd, ..Session::default() }, None).unwrap();
    let client = Clients::bundled().get(innertube::METADATA_CLIENT).unwrap().clone();

    // An ATV and a music video: each has its own thread, and the id is never remapped.
    for (label, id) in [("ATV", "lYBUbBu4W08"), ("music video", "dQw4w9WgXcQ")] {
        let page = it.comments(&client, id).await.expect("comments first page");
        eprintln!("{label} {id}: {:?}, {} threads", page.state, page.threads.len());
        if page.state == CommentsState::Disabled {
            eprintln!("  comments are off for this track, skipping");
            continue;
        }
        assert_eq!(page.state, CommentsState::Ok, "{label} has comments and none came back");
        let header = page.header.as_ref().expect("first page carries a header");
        let sorts: Vec<_> = header.sorts.iter().map(|s| s.key).collect();
        assert_eq!(sorts, [CommentSortKey::Top, CommentSortKey::Newest]);
        assert!(
            page.threads.iter().all(|t| !t.comment.id.is_empty()),
            "{label}: a thread has no id"
        );
        // One top comment with an empty body is one commenter's doing, not a shape change: it
        // turned the nightly red twice, on the runner's region only. A moved content path empties
        // every thread at once. The ids say which comment it was (`watch?v=<id>&lc=<comment id>`).
        let blank: Vec<_> = page
            .threads
            .iter()
            .filter(|t| t.comment.text.is_empty())
            .map(|t| t.comment.id.as_str())
            .collect();
        if !blank.is_empty() {
            eprintln!("  no text on {blank:?}");
        }
        assert!(
            blank.len() * 2 < page.threads.len(),
            "{label}: {} of {} threads have no text, the comment content path moved",
            blank.len(),
            page.threads.len()
        );

        let token = page.continuation.clone().expect("a second page token");
        let more =
            it.comments_continuation(&client, &token, page.read_as_account).await.expect("page 2");
        assert!(!more.threads.is_empty(), "page 2 came back empty");

        if let Some(rt) = page.threads.iter().find_map(|t| t.replies_token.clone()) {
            let replies =
                it.comment_replies(&client, &rt, page.read_as_account).await.expect("replies");
            assert!(!replies.replies.is_empty(), "replies token resolved to nothing");
        }
        let newest = header.sorts.iter().find(|s| s.key == CommentSortKey::Newest).unwrap();
        let sorted = it
            .comments_continuation(&client, &newest.token, page.read_as_account)
            .await
            .expect("sort switch");
        assert!(sorted.header.as_ref().is_some_and(|h| h.sorts.iter().any(|s| s.selected)));
    }
}

/// #536: the pages `playlist_pages` fetches by position must be exactly the ones a walk reaches one
/// token at a time. A public playlist anonymously (9 requests); with a session, Liked Music too.
///   [LIMUSIC_COOKIE=… LIMUSIC_VISITOR=…] cargo test -p innertube --features integration-tests playlist_pages -- --ignored --nocapture
#[tokio::test]
#[ignore]
async fn playlist_pages_match_the_walk() {
    let cookie = std::env::var("LIMUSIC_COOKIE").ok().filter(|s| !s.is_empty());
    let visitor = std::env::var("LIMUSIC_VISITOR").ok().filter(|s| !s.is_empty());
    let mut lists = vec![("VLPL5dDx681T4bR7ZF1IuWzOv1omlRbE7PiJ", Session::default())];
    if let Some(cookie) = cookie {
        lists.push((
            "VLLM",
            Session { cookie: Some(cookie), visitor_data: visitor, ..Session::default() },
        ));
    }
    let clients = Clients::bundled();
    let client = clients.get("WEB_REMIX").expect("WEB_REMIX client");
    for (id, session) in lists {
        let it = InnerTube::new(session, None).unwrap();
        let first = it.playlist(client, id, None).await.expect("page 1");
        // "6.2M views • 492 tracks • 30+ hours": the part with the track count.
        let total: usize = first
            .subtitle
            .as_deref()
            .and_then(|s| s.split('•').find(|p| p.contains("track") || p.contains("song")))
            .map(|p| p.chars().filter(char::is_ascii_digit).collect::<String>())
            .and_then(|d| d.parse().ok())
            .expect("a track count in the header");
        let token = first.continuation.expect("more than one page");

        let ahead = it.playlist_pages(client, &token, total).await.expect("pages ahead");
        let mut walked = Vec::new();
        let mut next = Some(token);
        for _ in 0..4 {
            let Some(t) = next.take() else { break };
            let page = it.playlist_continuation(client, &t).await.expect("walk");
            walked.extend(page.items);
            next = page.continuation;
        }
        let rows = |v: &[innertube::SongItem]| -> Vec<Option<String>> {
            v.iter().map(|s| s.set_video_id.clone()).collect()
        };
        eprintln!(
            "{id}: {total} tracks, {} rows ahead, {} walked",
            ahead.items.len(),
            walked.len()
        );
        assert!(ahead.items.len() > 100, "{id}: nothing was fetched ahead");
        assert_eq!(rows(&ahead.items), rows(&walked), "{id}: pages ahead differ from the walk");
        assert_eq!(ahead.continuation.is_some(), next.is_some(), "{id}: ends differ");
    }
}
